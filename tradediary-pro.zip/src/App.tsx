import { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Calendar,
  Briefcase,
  TrendingUp,
  LineChart,
  Plus,
  Sliders,
  Moon,
  Sun,
  Download,
  RotateCcw,
  Clock,
  ExternalLink,
} from 'lucide-react';

import { Trade, AppConfig } from './types';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import DashboardView from './components/DashboardView';
import CalendarView from './components/CalendarView';
import PortfolioView from './components/PortfolioView';
import PnlReportView from './components/PnlReportView';
import AnalyticsHubView from './components/AnalyticsHubView';
import TradeModal from './components/TradeModal';
import QuickAddModal from './components/QuickAddModal';
import CustomizationModal from './components/CustomizationModal';
import ImagePreviewModal from './components/ImagePreviewModal';

// --- Factory Defaults ---
const DEFAULT_CONFIG: AppConfig = {
  brandName: 'TradeDiary Pro',
  strategies: [
    'Order Block Mitigation',
    'FVG (Fair Value Gap) Reversal',
    'Opening Range Breakout',
    'Volume Profile POC Bounce',
    'EMA Dynamic Cross',
    'Mean Reversion Channel',
  ],
  ecosystems: ['Indian Market', 'US Equities', 'Crypto Derivatives', 'FX Majors'],
  outcomes: ['WIN (TP Target Hit)', 'LOSS (SL Triggered)', 'WIN (Manual Partial)', 'LOSS (Manual Early Cut)'],
  mistakes: [
    'No Mistakes',
    'FOMO / Early Chase',
    'Oversizing Position',
    'Moving SL to Break-Even Too Early',
    'Revenge Trade Recovery',
    'Ignoring Macro Checklist',
  ],
  theme: {
    primaryColor: '#6366f1', // Indigo-500
    successColor: '#10b981', // Emerald-500
    dangerColor: '#ef4444', // Red-500
    bgLight: '#f8fafc', // Slate-50
    bgDark: '#0b0f19', // Deep space-950 dark
    bg: 'mesh',
    font: '"Plus Jakarta Sans"',
    palette: 'default',
    chartGridColor: '#334155',
  },
};

const SEED_TRADES: Trade[] = [
  {
    date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    symbol: 'RELIANCE',
    marketCondition: 'Indian Market',
    currency: 'INR',
    entryPrice: 2450.0,
    quantity: 100,
    exitPrice: 2520.0,
    stopLossPrice: 2420.0,
    targetPrice: 2540.0,
    manualPnlAmount: '',
    calculatedPl: 7000.0,
    direction: 'LONG',
    tradeDuration: 'SWING',
    strategyTag: 'Order Block Mitigation',
    tradeStatus: 'WIN',
    ratingConfidence: 8,
    ratingSatisfaction: 9,
    emotionalState: 'Extremely Calm',
    lessonsLearned: 'Stuck beautifully to the narrative. Order block held support on the 15-minute timeframe.',
    mistakesMade: ['No Mistakes'],
    chartImage: '',
  },
  {
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    symbol: 'BTCUSDT',
    marketCondition: 'Crypto Derivatives',
    currency: 'USD',
    entryPrice: 62500.0,
    quantity: 0.5,
    exitPrice: 61800.0,
    stopLossPrice: 62900.0,
    targetPrice: 61000.0,
    manualPnlAmount: '',
    calculatedPl: 350.0, // Short: (entry - exit) * qty = (62500 - 61800) * 0.5 = 350
    direction: 'SHORT',
    tradeDuration: 'INTRADAY',
    strategyTag: 'FVG (Fair Value Gap) Reversal',
    tradeStatus: 'WIN',
    ratingConfidence: 7,
    ratingSatisfaction: 8,
    emotionalState: 'Patient',
    lessonsLearned: 'Fair value gap on 4H chart provided perfect resistance level.',
    mistakesMade: ['No Mistakes'],
    chartImage: '',
  },
  {
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    symbol: 'TCS',
    marketCondition: 'Indian Market',
    currency: 'INR',
    entryPrice: 3820.0,
    quantity: 50,
    exitPrice: 3780.0,
    stopLossPrice: 3800.0,
    targetPrice: 3890.0,
    manualPnlAmount: '',
    calculatedPl: -2000.0, // Long: (3780 - 3820) * 50 = -2000
    direction: 'LONG',
    tradeDuration: 'INTRADAY',
    strategyTag: 'Opening Range Breakout',
    tradeStatus: 'LOSS',
    ratingConfidence: 6,
    ratingSatisfaction: 3,
    emotionalState: 'Anxious',
    lessonsLearned: 'Violated standard rules. Trailing stop loss was moved too close before consolidation finished.',
    mistakesMade: ['FOMO / Early Chase'],
    chartImage: '',
  },
  {
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    symbol: 'AAPL',
    marketCondition: 'US Equities',
    currency: 'USD',
    entryPrice: 175.5,
    quantity: 120,
    exitPrice: 179.0,
    stopLossPrice: 173.8,
    targetPrice: 180.0,
    manualPnlAmount: '',
    calculatedPl: 420.0,
    direction: 'LONG',
    tradeDuration: 'SWING',
    strategyTag: 'EMA Dynamic Cross',
    tradeStatus: 'WIN',
    ratingConfidence: 9,
    ratingSatisfaction: 9,
    emotionalState: 'Highly Confident',
    lessonsLearned: 'Perfect 50/200 EMA crossover on daily chart. High relative volume.',
    mistakesMade: ['No Mistakes'],
    chartImage: '',
  },
];

export default function App() {
  // --- Persistent State Hooks ---
  const [trades, setTrades] = useState<Trade[]>([]);
  const [appConfig, setAppConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'calendar' | 'portfolio' | 'pnl' | 'analytics'>('dashboard');

  // --- Real-time Clock ---
  const [systemTime, setSystemTime] = useState<string>('');

  // --- Modals Controller State ---
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [editingTradeIndex, setEditingTradeIndex] = useState<number | null>(null);

  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isConfigOpen, setIsConfigOpen] = useState(false);

  const [previewImage, setPreviewImage] = useState<string>('');

  // 1. Initial Load from LocalStorage
  useEffect(() => {
    // Load config
    const storedConfig = localStorage.getItem('trade_diary_config_v2');
    if (storedConfig) {
      try {
        setAppConfig(JSON.parse(storedConfig));
      } catch (err) {
        console.error('Error parsing stored config, using default', err);
      }
    }

    // Load trades
    const storedTrades = localStorage.getItem('trade_diary_trades_v2');
    if (storedTrades) {
      try {
        setTrades(JSON.parse(storedTrades));
      } catch (err) {
        console.error('Error parsing stored trades, using defaults', err);
      }
    } else {
      // Seed default trades
      setTrades(SEED_TRADES);
      localStorage.setItem('trade_diary_trades_v2', JSON.stringify(SEED_TRADES));
    }

    // Load DarkMode preference
    const storedDark = localStorage.getItem('trade_diary_dark_v2');
    if (storedDark !== null) {
      setIsDarkMode(storedDark === 'true');
    }
  }, []);

  // 2. Synchronize Dark Mode Class
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('trade_diary_dark_v2', String(isDarkMode));
  }, [isDarkMode]);

  // 3. Keep real-time clock ticking
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setSystemTime(
        now.toLocaleString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          timeZoneName: 'short',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Helper: Persist Config changes
  const saveConfig = (newConfig: AppConfig) => {
    setAppConfig(newConfig);
    localStorage.setItem('trade_diary_config_v2', JSON.stringify(newConfig));
  };

  // Helper: Persist Trades changes
  const saveTradesList = (newList: Trade[]) => {
    setTrades(newList);
    localStorage.setItem('trade_diary_trades_v2', JSON.stringify(newList));
  };

  // Helper: Factory Restore
  const handleRestoreDefaults = () => {
    saveConfig(DEFAULT_CONFIG);
    saveTradesList(SEED_TRADES);
    setIsDarkMode(true);
  };

  // Helper: Clear entire ledger database
  const handleClearDatabase = () => {
    if (confirm('Are you absolutely sure you want to clear the entire ledger history? This is irreversible.')) {
      saveTradesList([]);
    }
  };

  // Add/Modify trade parameters handler
  const handleSaveTrade = (tradeObj: Trade) => {
    let computedPl = 0;
    if (tradeObj.manualPnlAmount !== '') {
      computedPl = Number(tradeObj.manualPnlAmount);
    } else {
      const entry = Number(tradeObj.entryPrice) || 0;
      const exit = Number(tradeObj.exitPrice) || 0;
      const qty = Number(tradeObj.quantity) || 0;

      if (tradeObj.direction === 'LONG') {
        computedPl = (exit - entry) * qty;
      } else {
        computedPl = (entry - exit) * qty;
      }
    }
    tradeObj.calculatedPl = computedPl;

    // Automatically assign win/loss based on sign of P&L
    tradeObj.tradeStatus = computedPl >= 0 ? 'WIN' : 'LOSS';

    const newList = [...trades];
    if (editingTradeIndex !== null) {
      // Edit
      newList[editingTradeIndex] = tradeObj;
    } else {
      // Add
      newList.push(tradeObj);
    }

    saveTradesList(newList);
    setEditingTradeIndex(null);
  };

  const handleEditTradeIndex = (idx: number) => {
    setEditingTradeIndex(idx);
    setIsTradeModalOpen(true);
  };

  const handleRemoveTradeIndex = (idx: number) => {
    if (confirm('Are you sure you want to delete this trade from the ledger permanently?')) {
      const newList = trades.filter((_, i) => i !== idx);
      saveTradesList(newList);
    }
  };

  // Export ledger to standard Excel file
  const handleExportExcel = () => {
    if (trades.length === 0) {
      alert('Ledger is empty. No parameters to export.');
      return;
    }

    // Construct XML Spreadsheet 2003 format
    let xml = `<?xml version="1.0" encoding="utf-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <Styles>
  <Style ss.ID="Header">
   <Font ss.Bold="1" ss.Color="#FFFFFF"/>
   <Interior ss.Color="#4F46E5" ss.Pattern="Solid"/>
  </Style>
 </Styles>
 <Worksheet ss.Name="Ledger Logs">
  <Table>`;

    // Headers
    xml += `
   <Row>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Date</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Asset Symbol</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Direction</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Ecosystem</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Strategy Setup</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Currency</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Entry Price</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Quantity</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Exit Price</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Net Returns P&L</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Confidence (1-10)</Data></Cell>
    <Cell ss.StyleID="Header"><Data ss.Type="String">Lessons / Notes</Data></Cell>
   </Row>`;

    // Rows
    trades.forEach((t) => {
      xml += `
   <Row>
    <Cell><Data ss.Type="String">${t.date || ''}</Data></Cell>
    <Cell><Data ss.Type="String">${t.symbol || ''}</Data></Cell>
    <Cell><Data ss.Type="String">${t.direction || ''}</Data></Cell>
    <Cell><Data ss.Type="String">${t.marketCondition || ''}</Data></Cell>
    <Cell><Data ss.Type="String">${t.strategyTag || ''}</Data></Cell>
    <Cell><Data ss.Type="String">${t.currency || ''}</Data></Cell>
    <Cell><Data ss.Type="Number">${t.entryPrice || 0}</Data></Cell>
    <Cell><Data ss.Type="Number">${t.quantity || 0}</Data></Cell>
    <Cell><Data ss.Type="Number">${t.exitPrice || 0}</Data></Cell>
    <Cell><Data ss.Type="Number">${t.calculatedPl || 0}</Data></Cell>
    <Cell><Data ss.Type="Number">${t.ratingConfidence || 5}</Data></Cell>
    <Cell><Data ss.Type="String">${t.lessonsLearned || ''}</Data></Cell>
   </Row>`;
    });

    xml += `
  </Table>
 </Worksheet>
</Workbook>`;

    const blob = new Blob([xml], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${appConfig.brandName}_Ledger_Export.xls`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export ledger to a Google Sheets optimized CSV file
  const handleExportCSVForGoogleSheets = () => {
    if (trades.length === 0) {
      alert('Ledger is empty. No parameters to export.');
      return;
    }

    const escapeCSV = (val: any) => {
      if (val === undefined || val === null) return '';
      const str = String(val);
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const headers = [
      'Date',
      'Asset Symbol',
      'Direction',
      'Ecosystem',
      'Strategy Setup',
      'Currency',
      'Entry Price',
      'Quantity',
      'Exit Price',
      'Net Returns P&L',
      'Confidence (1-10)',
      'Lessons / Notes'
    ];

    const rows = trades.map((t) => [
      escapeCSV(t.date),
      escapeCSV(t.symbol),
      escapeCSV(t.direction),
      escapeCSV(t.marketCondition),
      escapeCSV(t.strategyTag),
      escapeCSV(t.currency),
      escapeCSV(t.entryPrice),
      escapeCSV(t.quantity),
      escapeCSV(t.exitPrice),
      escapeCSV(t.calculatedPl),
      escapeCSV(t.ratingConfidence),
      escapeCSV(t.lessonsLearned)
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${appConfig.brandName}_Google_Sheets_Import.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export ledger performance report to beautiful PDF format
  const handleExportPDF = () => {
    if (trades.length === 0) {
      alert('Ledger is empty. No parameters to export.');
      return;
    }

    const doc = new jsPDF();
    
    // Header & Brand Styling
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(22);
    doc.setTextColor(79, 70, 229); // Brand primary color (Indigo-600)
    doc.text(appConfig.brandName, 14, 22);

    doc.setFontSize(10);
    doc.setFont('Helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Trading Ledger Performance Summary Report', 14, 29);
    
    // Generation Metadata
    const nowStr = new Date().toLocaleString();
    doc.text(`Generated: ${nowStr} | Total Records: ${trades.length}`, 14, 35);

    // Summary Analytics Calculation
    const totalTrades = trades.length;
    const wins = trades.filter((t) => t.tradeStatus === 'WIN').length;
    const losses = trades.filter((t) => t.tradeStatus === 'LOSS').length;
    const winRate = totalTrades > 0 ? ((wins / totalTrades) * 100).toFixed(1) : '0.0';
    
    const totalPl = trades.reduce((sum, t) => sum + (t.calculatedPl || 0), 0);
    const formattedPl = (totalPl >= 0 ? '+' : '') + totalPl.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    // Summary Card Grid (Background fill)
    doc.setFillColor(248, 250, 252); // Tailwind slate-50
    doc.roundedRect(14, 40, 182, 22, 3, 3, 'F');
    
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text('TOTAL TRADES', 20, 46);
    doc.text('WIN RATE & RECORD', 65, 46);
    doc.text('NET BALANCE P&L', 115, 46);

    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(String(totalTrades), 20, 54);
    doc.text(`${winRate}% (${wins} W - ${losses} L)`, 65, 54);
    
    if (totalPl >= 0) {
      doc.setTextColor(16, 185, 129); // emerald-500
    } else {
      doc.setTextColor(239, 68, 68); // red-500
    }
    doc.text(formattedPl, 115, 54);

    // Document Table Layout setup
    const tableHeaders = [['Date', 'Symbol', 'Dir', 'Ecosystem', 'Strategy Setup', 'Status', 'Net Return']];
    const tableRows = trades.map((t) => [
      t.date || '',
      t.symbol || '',
      t.direction || '',
      t.marketCondition || '',
      t.strategyTag || '',
      t.tradeStatus || '',
      (t.calculatedPl >= 0 ? '+' : '') + (t.calculatedPl || 0).toFixed(2)
    ]);

    autoTable(doc, {
      startY: 68,
      head: tableHeaders,
      body: tableRows,
      theme: 'grid',
      headStyles: {
        fillColor: [79, 70, 229],
        textColor: [255, 255, 255],
        fontSize: 9,
        fontStyle: 'bold'
      },
      columnStyles: {
        0: { cellWidth: 22 }, // Date
        1: { cellWidth: 24, fontStyle: 'bold' }, // Symbol
        2: { cellWidth: 14 }, // Direction
        3: { cellWidth: 32 }, // Ecosystem
        4: { cellWidth: 39 }, // Strategy Tag
        5: { cellWidth: 18 }, // Status
        6: { cellWidth: 33, halign: 'right' } // Net Return
      },
      styles: {
        fontSize: 8,
        cellPadding: 3
      },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index === 5) {
          const status = data.cell.raw;
          if (status === 'WIN') {
            data.cell.styles.textColor = [16, 185, 129];
            data.cell.styles.fontStyle = 'bold';
          } else if (status === 'LOSS') {
            data.cell.styles.textColor = [239, 68, 68];
            data.cell.styles.fontStyle = 'bold';
          }
        }
        if (data.section === 'body' && data.column.index === 6) {
          const rawVal = String(data.cell.raw);
          if (rawVal.startsWith('+')) {
            data.cell.styles.textColor = [16, 185, 129];
          } else if (rawVal.startsWith('-')) {
            data.cell.styles.textColor = [239, 68, 68];
          }
        }
      }
    });

    doc.save(`${appConfig.brandName}_Ledger_Report.pdf`);
  };

  // Chart layout color mappings computed dynamically
  const gridLineColor = appConfig.theme.chartGridColor || (isDarkMode ? '#334155' : '#e2e8f0');
  const tickTextColor = isDarkMode ? '#94a3b8' : '#64748b';

  const chartColors = {
    grid: gridLineColor,
    tick: tickTextColor,
    primary: appConfig.theme.primaryColor,
    success: appConfig.theme.successColor,
    danger: appConfig.theme.dangerColor,
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden flex flex-col font-sans transition-all duration-500">
      {/* 
        Inject Custom Styles based on variables inside the customizer!
        This allows full-fidelity visual updates in real time.
      */}
      <style>{`
        :root {
          --color-primary: ${appConfig.theme.primaryColor};
          --color-primary-hover: ${appConfig.theme.primaryColor}df;
          --color-success: ${appConfig.theme.successColor};
          --color-danger: ${appConfig.theme.dangerColor};
          --font-family: ${appConfig.theme.font}, system-ui, sans-serif;
        }
        body {
          font-family: var(--font-family);
          background-color: ${isDarkMode ? appConfig.theme.bgDark : appConfig.theme.bgLight};
          color: ${isDarkMode ? '#f8fafc' : '#0f172a'};
        }
        .glass-panel {
          background-color: ${isDarkMode ? 'rgba(255, 255, 255, 0.04)' : 'rgba(255, 255, 255, 0.45)'};
          border: 1px solid ${isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(15, 23, 42, 0.08)'};
          backdrop-filter: blur(24px) saturate(120%);
          -webkit-backdrop-filter: blur(24px) saturate(120%);
          box-shadow: ${isDarkMode ? '0 8px 32px 0 rgba(0, 0, 0, 0.3)' : '0 8px 32px 0 rgba(31, 38, 135, 0.04)'};
        }
        /* Custom background styling types */
        ${
          appConfig.theme.bg === 'mesh'
            ? `
          .bg-canvas {
            background-color: ${isDarkMode ? '#020617' : '#f8fafc'};
            background-image: 
              radial-gradient(at 0% 0%, rgba(79, 70, 229, ${isDarkMode ? '0.25' : '0.12'}) 0px, transparent 50%),
              radial-gradient(at 100% 0%, rgba(139, 92, 246, ${isDarkMode ? '0.2' : '0.1'}) 0px, transparent 50%),
              radial-gradient(at 50% 100%, rgba(16, 185, 129, ${isDarkMode ? '0.12' : '0.08'}) 0px, transparent 50%);
          }
          body {
            background-color: ${isDarkMode ? '#020617' : '#f8fafc'} !important;
          }
        `
            : appConfig.theme.bg === 'gradient'
            ? `
          .bg-canvas {
            background-image: radial-gradient(circle at 10% 20%, ${appConfig.theme.primaryColor}1a 0%, transparent 40%),
                              radial-gradient(circle at 90% 80%, ${appConfig.theme.successColor}15 0%, transparent 45%);
          }
        `
            : `
          .bg-canvas {
            background-image: none;
          }
        `
        }
      `}</style>

      {/* Dynamic Background Canvas */}
      <div className="fixed inset-0 bg-canvas pointer-events-none -z-10 transition-all duration-700"></div>

      {/* Header Panel */}
      <header className="sticky top-0 z-50 glass-panel border-b border-white/20 dark:border-slate-800/40 backdrop-blur-xl shrink-0">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="relative group">
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-primary to-purple-500 opacity-75 blur-md group-hover:opacity-100 transition duration-500"></div>
              <div className="relative bg-slate-900 text-white rounded-xl p-2.5 font-bold tracking-widest text-lg select-none border border-white/10 shadow-lg">
                TD
              </div>
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                {appConfig.brandName}
                <span className="text-[10px] bg-primary/10 text-primary border border-primary/20 px-2.5 py-0.5 rounded-full font-black uppercase tracking-widest animate-pulse">
                  v2.0 PRO
                </span>
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold tracking-tight mt-0.5">
                Enterprise Ledger & Analytics Engine
              </p>
            </div>
          </div>

          {/* Controls Panel */}
          <div className="flex items-center gap-3 flex-wrap">
            {/* Live Clock display */}
            <div className="hidden lg:flex items-center gap-2 bg-white/40 dark:bg-slate-900/30 border border-slate-300/40 dark:border-slate-800/60 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 font-mono shadow-sm">
              <Clock className="w-4 h-4 text-primary" />
              <span>{systemTime || 'STABLE LOCK'}</span>
            </div>

            {/* Config setup */}
            <button
              onClick={() => setIsConfigOpen(true)}
              className="bg-white/40 dark:bg-slate-900/40 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-white px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-tight transition duration-300 border border-slate-300/40 dark:border-slate-800/60 shadow-sm flex items-center gap-2"
              title="Launch Customize Engine"
            >
              <Sliders className="w-4 h-4 text-primary" />
              <span className="hidden sm:inline">Preferences</span>
            </button>

            {/* Google Sheets CSV Exporter */}
            <button
              onClick={handleExportCSVForGoogleSheets}
              className="bg-emerald-500/10 dark:bg-emerald-500/20 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-tight transition duration-300 border border-emerald-500/30 dark:border-emerald-500/40 shadow-sm flex items-center gap-2"
              title="Download CSV for direct import to Google Sheets"
            >
              <Download className="w-4 h-4 text-emerald-500" />
              <span className="hidden sm:inline">Google Sheets (CSV)</span>
            </button>

            {/* PDF Exporter */}
            <button
              onClick={handleExportPDF}
              className="bg-rose-500/10 dark:bg-rose-500/20 hover:bg-rose-500/20 text-rose-700 dark:text-rose-300 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-tight transition duration-300 border border-rose-500/30 dark:border-rose-500/40 shadow-sm flex items-center gap-2"
              title="Download trade diary as PDF report"
            >
              <Download className="w-4 h-4 text-rose-500" />
              <span className="hidden sm:inline">Download PDF</span>
            </button>

            {/* Purge / Restore */}
            <button
              onClick={handleRestoreDefaults}
              className="bg-white/40 dark:bg-slate-900/40 hover:bg-rose-100 dark:hover:bg-rose-950/20 text-slate-700 dark:text-white hover:text-rose-600 dark:hover:text-rose-400 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-tight transition duration-300 border border-slate-300/40 dark:border-slate-800/60 shadow-sm flex items-center gap-2"
              title="Restore factory presets"
            >
              <RotateCcw className="w-4 h-4 text-rose-500" />
              <span className="hidden sm:inline">Reset Defaults</span>
            </button>

            {/* Dark Mode */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="bg-white/40 dark:bg-slate-900/40 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-white p-2.5 rounded-xl shadow-sm border border-slate-300/40 dark:border-slate-800/60 transition"
              title="Switch Visual Canvas"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-indigo-500" />}
            </button>
          </div>
        </div>
      </header>

      {/* Tabs Navigation */}
      <div className="bg-slate-100/50 dark:bg-slate-900/30 border-b border-slate-200/50 dark:border-slate-800/40 shrink-0">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <nav className="flex space-x-6 text-sm font-bold tracking-tight overflow-x-auto custom-scrollbar">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`py-4 border-b-2 transition-all flex items-center gap-2 duration-300 ${
                activeTab === 'dashboard'
                  ? 'border-primary text-slate-900 dark:text-white'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-primary" /> Dashboard
            </button>
            <button
              onClick={() => setActiveTab('calendar')}
              className={`py-4 border-b-2 transition-all flex items-center gap-2 duration-300 ${
                activeTab === 'calendar'
                  ? 'border-primary text-slate-900 dark:text-white'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-4 h-4 text-primary" /> Calendar
            </button>
            <button
              onClick={() => setActiveTab('portfolio')}
              className={`py-4 border-b-2 transition-all flex items-center gap-2 duration-300 ${
                activeTab === 'portfolio'
                  ? 'border-primary text-slate-900 dark:text-white'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Briefcase className="w-4 h-4 text-primary" /> Portfolio
            </button>
            <button
              onClick={() => setActiveTab('pnl')}
              className={`py-4 border-b-2 transition-all flex items-center gap-2 duration-300 ${
                activeTab === 'pnl'
                  ? 'border-primary text-slate-900 dark:text-white'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <TrendingUp className="w-4 h-4 text-primary" /> P&L Report
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`py-4 border-b-2 transition-all flex items-center gap-2 duration-300 ${
                activeTab === 'analytics'
                  ? 'border-primary text-slate-900 dark:text-white'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <LineChart className="w-4 h-4 text-primary" /> Analytics Hub
            </button>
          </nav>

          {/* Quick Ledger entries */}
          <div className="flex gap-2">
            <button
              onClick={() => {
                setEditingTradeIndex(null);
                setIsTradeModalOpen(true);
              }}
              className="bg-primary hover:bg-primary-hover text-white text-xs font-bold tracking-tight px-4 py-2.5 rounded-xl shadow-md transition duration-300 hover:-translate-y-0.5 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Add Record
            </button>
          </div>
        </div>
      </div>

      {/* Main Container / Content Views */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 overflow-y-auto">
        {activeTab === 'dashboard' && (
          <DashboardView
            trades={trades}
            appConfig={appConfig}
            onEditTrade={handleEditTradeIndex}
            onRemoveTrade={handleRemoveTradeIndex}
            onViewImage={setPreviewImage}
            colors={chartColors}
          />
        )}

        {activeTab === 'calendar' && <CalendarView trades={trades} appConfig={appConfig} />}

        {activeTab === 'portfolio' && (
          <PortfolioView trades={trades} appConfig={appConfig} colors={chartColors} />
        )}

        {activeTab === 'pnl' && <PnlReportView trades={trades} colors={chartColors} />}

        {activeTab === 'analytics' && (
          <AnalyticsHubView trades={trades} appConfig={appConfig} colors={chartColors} />
        )}
      </main>

      {/* Database control footer */}
      <footer className="py-6 border-t border-slate-200/50 dark:border-slate-800/40 text-center font-semibold text-slate-400 bg-slate-100/30 dark:bg-slate-950/20 backdrop-blur-md shrink-0">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs">
          <div>
            &copy; {new Date().getFullYear()} {appConfig.brandName}. Powered by React 19 & Recharts.
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleClearDatabase}
              className="text-slate-500 dark:text-slate-400 hover:text-rose-500 transition duration-300"
            >
              Purge History Log
            </button>
            <span className="text-slate-300 dark:text-slate-800">|</span>
            <span className="flex items-center gap-1 text-primary">
              Enterprise Grade <ExternalLink className="w-3 h-3" />
            </span>
          </div>
        </div>
      </footer>

      {/* Bottom Floating Action button for Quick Entry */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsQuickAddOpen(true)}
          className="relative group p-4 bg-primary hover:bg-primary-hover text-white rounded-full shadow-2xl transition duration-300 hover:scale-110 active:scale-95"
          title="Instant Quick Add"
        >
          <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-primary to-purple-500 opacity-50 blur-md group-hover:opacity-75 transition duration-500"></div>
          <Plus className="w-6 h-6 relative z-10" />
        </button>
      </div>

      {/* --- Modals Overlay Mounts --- */}
      <TradeModal
        isOpen={isTradeModalOpen}
        onClose={() => {
          setIsTradeModalOpen(false);
          setEditingTradeIndex(null);
        }}
        onSave={handleSaveTrade}
        editingTrade={editingTradeIndex !== null ? trades[editingTradeIndex] : null}
        appConfig={appConfig}
      />

      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onAdd={handleSaveTrade}
        onDetailedEntry={() => {
          setEditingTradeIndex(null);
          setIsTradeModalOpen(true);
        }}
        defaultEcosystem={appConfig.ecosystems[0]}
      />

      <CustomizationModal
        isOpen={isConfigOpen}
        onClose={() => setIsConfigOpen(false)}
        appConfig={appConfig}
        onSave={saveConfig}
        onRestore={handleRestoreDefaults}
      />

      <ImagePreviewModal
        isOpen={!!previewImage}
        onClose={() => setPreviewImage('')}
        imageSrc={previewImage}
      />
    </div>
  );
}
