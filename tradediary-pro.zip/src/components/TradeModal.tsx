import React, { useState, useEffect } from 'react';
import { X, Image as ImageIcon } from 'lucide-react';
import { Trade, AppConfig } from '../types';

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (trade: Trade) => void;
  editingTrade: Trade | null;
  appConfig: AppConfig;
}

export default function TradeModal({
  isOpen,
  onClose,
  onSave,
  editingTrade,
  appConfig,
}: TradeModalProps) {
  // Tabs: 'general' | 'psychology'
  const [activeTab, setActiveTab] = useState<'general' | 'psychology'>('general');

  // General Metadata Fields
  const [date, setDate] = useState('');
  const [symbol, setSymbol] = useState('');
  const [marketCondition, setMarketCondition] = useState('');
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');
  const [entryPrice, setEntryPrice] = useState<number | ''>('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [exitPrice, setExitPrice] = useState<number | ''>('');
  const [stopLossPrice, setStopLossPrice] = useState<number | ''>('');
  const [targetPrice, setTargetPrice] = useState<number | ''>('');
  const [strategyTag, setStrategyTag] = useState('');
  const [customStrategyName, setCustomStrategyName] = useState('');
  const [manualPnlAmount, setManualPnlAmount] = useState<number | ''>('');
  const [direction, setDirection] = useState<'LONG' | 'SHORT'>('LONG');
  const [tradeDuration, setTradeDuration] = useState<'INTRADAY' | 'SWING'>('INTRADAY');
  const [chartImage, setChartImage] = useState('');
  const [tradeStatus, setTradeStatus] = useState<'WIN' | 'LOSS'>('WIN');

  // Psychology Matrix Fields
  const [ratingConfidence, setRatingConfidence] = useState<number>(5);
  const [ratingSatisfaction, setRatingSatisfaction] = useState<number>(5);
  const [emotionalState, setEmotionalState] = useState('');
  const [lessonsLearned, setLessonsLearned] = useState('');
  const [selectedMistakes, setSelectedMistakes] = useState<string[]>([]);

  // Local variables for show custom input
  const [showCustomStrategy, setShowCustomStrategy] = useState(false);

  // Sync inputs when editingTrade changes
  useEffect(() => {
    if (isOpen) {
      setActiveTab('general');
      if (editingTrade) {
        setDate(editingTrade.date);
        setSymbol(editingTrade.symbol);
        setMarketCondition(editingTrade.marketCondition || appConfig.ecosystems[0] || 'Indian Market');
        setCurrency(editingTrade.currency || 'INR');
        setEntryPrice(editingTrade.entryPrice || '');
        setQuantity(editingTrade.quantity || '');
        setExitPrice(editingTrade.exitPrice || '');
        setStopLossPrice(editingTrade.stopLossPrice || '');
        setTargetPrice(editingTrade.targetPrice || '');
        setManualPnlAmount(editingTrade.manualPnlAmount ?? '');
        setDirection(editingTrade.direction || 'LONG');
        setTradeDuration(editingTrade.tradeDuration || 'INTRADAY');
        setChartImage(editingTrade.chartImage || '');
        setTradeStatus(editingTrade.tradeStatus || 'WIN');

        // Check if strategy tag exists in current lists
        if (appConfig.strategies.includes(editingTrade.strategyTag)) {
          setStrategyTag(editingTrade.strategyTag);
          setShowCustomStrategy(false);
          setCustomStrategyName('');
        } else {
          setStrategyTag('__ADD_NEW__');
          setShowCustomStrategy(true);
          setCustomStrategyName(editingTrade.strategyTag || '');
        }

        setRatingConfidence(editingTrade.ratingConfidence ?? 5);
        setRatingSatisfaction(editingTrade.ratingSatisfaction ?? 5);
        setEmotionalState(editingTrade.emotionalState || '');
        setLessonsLearned(editingTrade.lessonsLearned || '');
        setSelectedMistakes(editingTrade.mistakesMade || []);
      } else {
        // Defaults for new trade
        setDate(new Date().toISOString().split('T')[0]);
        setSymbol('');
        setMarketCondition(appConfig.ecosystems[0] || 'Indian Market');
        setCurrency('INR');
        setEntryPrice('');
        setQuantity('');
        setExitPrice('');
        setStopLossPrice('');
        setTargetPrice('');
        setManualPnlAmount('');
        setDirection('LONG');
        setTradeDuration('INTRADAY');
        setChartImage('');
        setTradeStatus('WIN');
        setStrategyTag(appConfig.strategies[0] || '');
        setShowCustomStrategy(false);
        setCustomStrategyName('');

        setRatingConfidence(5);
        setRatingSatisfaction(5);
        setEmotionalState('');
        setLessonsLearned('');
        setSelectedMistakes([]);
      }
    }
  }, [isOpen, editingTrade, appConfig]);

  if (!isOpen) return null;

  // Perform dynamic calculations
  const entryVal = parseFloat(entryPrice as string) || 0;
  const qtyVal = parseFloat(quantity as string) || 0;
  const exitVal = parseFloat(exitPrice as string) || 0;
  const slVal = parseFloat(stopLossPrice as string) || 0;
  const tpVal = parseFloat(targetPrice as string) || 0;

  const totalBase = (entryVal * qtyVal).toFixed(2);

  // Live Risk/Reward profile
  let liveRisk = 0;
  let liveReward = 0;
  if (entryVal > 0 && qtyVal > 0) {
    if (slVal > 0) {
      liveRisk = direction === 'LONG' ? (entryVal - slVal) * qtyVal : (slVal - entryVal) * qtyVal;
    }
    if (tpVal > 0) {
      liveReward = direction === 'LONG' ? (tpVal - entryVal) * qtyVal : (entryVal - tpVal) * qtyVal;
    }
  }
  liveRisk = Math.max(0, liveRisk);
  liveReward = Math.max(0, liveReward);
  const liveRR = liveRisk > 0 ? (liveReward / liveRisk).toFixed(2) : '0.00';

  const sign = currency === 'USD' ? '$' : '₹';

  const handleStrategyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setStrategyTag(val);
    if (val === '__ADD_NEW__') {
      setShowCustomStrategy(true);
    } else {
      setShowCustomStrategy(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setChartImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMistakeToggle = (mistake: string) => {
    setSelectedMistakes((prev) =>
      prev.includes(mistake) ? prev.filter((m) => m !== mistake) : [...prev, mistake]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!symbol) return;

    let finalStrategy = strategyTag;
    if (strategyTag === '__ADD_NEW__') {
      finalStrategy = customStrategyName.trim() || 'Unassigned';
    }

    const tradeObj: Trade = {
      date,
      symbol: symbol.toUpperCase().trim(),
      marketCondition,
      currency,
      entryPrice: entryVal,
      quantity: qtyVal,
      exitPrice: exitVal,
      stopLossPrice: slVal,
      targetPrice: tpVal,
      manualPnlAmount: manualPnlAmount !== '' ? parseFloat(manualPnlAmount as string) || 0 : '',
      direction,
      tradeDuration,
      strategyTag: finalStrategy,
      tradeStatus,
      ratingConfidence,
      ratingSatisfaction,
      emotionalState: emotionalState.trim() || 'Focused',
      lessonsLearned: lessonsLearned.trim() || 'N/A',
      mistakesMade: selectedMistakes.length > 0 ? selectedMistakes : ['No Mistakes'],
      chartImage,
    };

    onSave(tradeObj);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 dark:bg-slate-950/60 backdrop-blur-xl flex items-center justify-center z-[60] p-4 overflow-y-auto transition-all">
      <div className="glass-panel w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden my-8 border-white/40 dark:border-slate-700/50 animate-fade-in max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center px-6 py-5 border-b border-white/30 dark:border-slate-800/60 bg-white/30 dark:bg-slate-900/30 backdrop-blur-md shrink-0">
          <h3 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            {editingTrade ? 'Modify Parameters' : 'Deep Entry Ledger'}
          </h3>
          <button
            onClick={onClose}
            className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition duration-300 p-1 rounded-lg hover:bg-white/50 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex px-6 pt-3 space-x-6 border-b border-white/30 dark:border-slate-800/60 text-sm bg-white/20 dark:bg-slate-900/20 backdrop-blur-sm shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('general')}
            className={`pb-3 border-b-2 font-bold tracking-tight flex items-center gap-2 transition duration-300 ${
              activeTab === 'general' ? 'border-primary text-slate-900 dark:text-white' : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            General Metadata
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('psychology')}
            className={`pb-3 border-b-2 font-bold tracking-tight flex items-center gap-2 transition duration-300 ${
              activeTab === 'psychology' ? 'border-primary text-slate-900 dark:text-white' : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Psychology Matrix
          </button>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'general' && (
            <div className="space-y-6 animate-fade-in">
              {/* Row 1 */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Ticker <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={symbol}
                    onChange={(e) => setSymbol(e.target.value)}
                    placeholder="e.g. RELIANCE"
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-bold text-slate-900 dark:text-white uppercase focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Ecosystem
                  </label>
                  <select
                    value={marketCondition}
                    onChange={(e) => setMarketCondition(e.target.value)}
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 cursor-pointer transition-all backdrop-blur-md"
                  >
                    {appConfig.ecosystems.map((eco) => (
                      <option key={eco} value={eco}>
                        {eco}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Currency
                  </label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as 'INR' | 'USD')}
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 cursor-pointer transition-all backdrop-blur-md"
                  >
                    <option value="INR">Rupee (INR)</option>
                    <option value="USD">Dollar (USD)</option>
                  </select>
                </div>
              </div>

              {/* Row 2 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Entry Price <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={entryPrice}
                    onChange={(e) => setEntryPrice(e.target.value !== '' ? parseFloat(e.target.value) : '')}
                    placeholder="0.00"
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                      Qty <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value !== '' ? parseFloat(e.target.value) : '')}
                      placeholder="0"
                      className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                      Total Base
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={totalBase}
                      className="w-full bg-white/30 dark:bg-slate-900/40 border border-white/50 dark:border-slate-800/70 rounded-xl p-3 text-slate-600 dark:text-slate-400 font-mono font-bold outline-none backdrop-blur-md"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Exit Price <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={exitPrice}
                    onChange={(e) => setExitPrice(e.target.value !== '' ? parseFloat(e.target.value) : '')}
                    placeholder="0.00"
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                    required
                  />
                </div>
              </div>

              {/* Row 3 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                      Stop Loss <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={stopLossPrice}
                      onChange={(e) => setStopLossPrice(e.target.value !== '' ? parseFloat(e.target.value) : '')}
                      placeholder="0.00"
                      className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                      Take Profit <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={targetPrice}
                      onChange={(e) => setTargetPrice(e.target.value !== '' ? parseFloat(e.target.value) : '')}
                      placeholder="0.00"
                      className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Setup Tag
                  </label>
                  <select
                    value={strategyTag}
                    onChange={handleStrategyChange}
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 cursor-pointer transition-all backdrop-blur-md"
                  >
                    {appConfig.strategies.map((strat) => (
                      <option key={strat} value={strat}>
                        {strat}
                      </option>
                    ))}
                    <option value="__ADD_NEW__">+ Add New Strategy...</option>
                  </select>
                  {showCustomStrategy && (
                    <div className="mt-2">
                      <input
                        type="text"
                        value={customStrategyName}
                        onChange={(e) => setCustomStrategyName(e.target.value)}
                        placeholder="Custom setup name"
                        className="w-full bg-white/70 dark:bg-slate-900/70 border border-primary/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md animate-fade-in"
                        required
                      />
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Manual P&L Override
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={manualPnlAmount}
                    onChange={(e) => setManualPnlAmount(e.target.value !== '' ? parseFloat(e.target.value) : '')}
                    placeholder="Auto-computed if empty"
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                  />
                </div>
              </div>

              {/* Row 4 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="bg-white/40 dark:bg-slate-900/40 p-4 rounded-xl border border-white/50 dark:border-slate-700/50 flex flex-col justify-between backdrop-blur-md">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Direction Vector
                  </span>
                  <div className="flex gap-4 mt-3">
                    <label className="flex items-center gap-2 cursor-pointer select-none text-sm font-bold text-slate-800 dark:text-white">
                      <input
                        type="radio"
                        name="direction"
                        value="LONG"
                        checked={direction === 'LONG'}
                        onChange={() => setDirection('LONG')}
                        className="w-4 h-4"
                        style={{ accentColor: 'var(--color-primary)' }}
                      />{' '}
                      LONG
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer select-none text-sm font-bold text-slate-800 dark:text-white">
                      <input
                        type="radio"
                        name="direction"
                        value="SHORT"
                        checked={direction === 'SHORT'}
                        onChange={() => setDirection('SHORT')}
                        className="w-4 h-4"
                        style={{ accentColor: 'var(--color-primary)' }}
                      />{' '}
                      SHORT
                    </label>
                  </div>
                </div>
                <div className="bg-white/40 dark:bg-slate-900/40 p-4 rounded-xl border border-white/50 dark:border-slate-700/50 flex flex-col justify-between backdrop-blur-md">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Horizon
                  </span>
                  <div className="flex gap-4 mt-3">
                    <label className="flex items-center gap-2 cursor-pointer select-none text-sm font-bold text-slate-800 dark:text-white">
                      <input
                        type="radio"
                        name="tradeDuration"
                        value="INTRADAY"
                        checked={tradeDuration === 'INTRADAY'}
                        onChange={() => setTradeDuration('INTRADAY')}
                        className="w-4 h-4"
                        style={{ accentColor: 'var(--color-primary)' }}
                      />{' '}
                      Intraday
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer select-none text-sm font-bold text-slate-800 dark:text-white">
                      <input
                        type="radio"
                        name="tradeDuration"
                        value="SWING"
                        checked={tradeDuration === 'SWING'}
                        onChange={() => setTradeDuration('SWING')}
                        className="w-4 h-4"
                        style={{ accentColor: 'var(--color-primary)' }}
                      />{' '}
                      Swing
                    </label>
                  </div>
                </div>
                <div className="bg-white/50 dark:bg-slate-900/60 p-4 rounded-xl border border-white/60 dark:border-slate-700/60 space-y-2 font-mono text-xs relative overflow-hidden group backdrop-blur-lg shadow-inner">
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent pointer-events-none"></div>
                  <div className="flex justify-between relative z-10">
                    <span className="text-slate-500 dark:text-slate-400 font-bold">Live Risk:</span>
                    <span className="text-rose-500 dark:text-rose-400 font-bold">
                      {sign}
                      {liveRisk.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between relative z-10">
                    <span className="text-slate-500 dark:text-slate-400 font-bold">Live Reward:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                      {sign}
                      {liveReward.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between border-t border-slate-300/50 dark:border-slate-700/50 pt-2 mt-1 relative z-10">
                    <span className="text-slate-600 dark:text-slate-300 font-bold tracking-widest uppercase text-[10px]">
                      Risk/Reward:
                    </span>
                    <span className="text-primary font-black">1:{liveRR}</span>
                  </div>
                </div>
              </div>

              {/* Row 5 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Chart Attachment
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-2 text-xs font-medium text-slate-600 dark:text-slate-400 focus:outline-none file:mr-4 file:py-1.5 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-primary file:text-white hover:file:bg-primary-hover file:cursor-pointer transition-all backdrop-blur-md"
                  />
                  {chartImage && (
                    <p className="text-[10px] text-amber-600 dark:text-amber-500 font-bold mt-2 ml-1">
                      ⚠️ A layout image is cached. Uploading overrides it.
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                    Outcome Summary <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={tradeStatus}
                    onChange={(e) => setTradeStatus(e.target.value as 'WIN' | 'LOSS')}
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-bold text-slate-900 dark:text-white focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 cursor-pointer transition-all backdrop-blur-md"
                  >
                    {appConfig.outcomes.map((o) => {
                      const val = o.toUpperCase().includes('WIN') ? 'WIN' : 'LOSS';
                      return (
                        <option key={o} value={val}>
                          {o}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'psychology' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  {/* Slider 1 */}
                  <div className="space-y-3">
                    <label className="block text-sm font-bold tracking-tight text-slate-900 dark:text-white">
                      Entry Confidence (1-10)
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={ratingConfidence}
                      onChange={(e) => setRatingConfidence(parseInt(e.target.value))}
                      className="w-full bg-slate-200/50 dark:bg-slate-800/50 h-2 rounded-lg cursor-pointer"
                      style={{ accentColor: 'var(--color-primary)' }}
                    />
                    <div className="flex justify-between text-xs text-slate-500 font-bold px-1">
                      <span>Low</span>
                      <span className="text-primary font-black bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md font-mono">
                        Val: {ratingConfidence}
                      </span>
                      <span>High</span>
                    </div>
                  </div>

                  {/* Slider 2 */}
                  <div className="space-y-3">
                    <label className="block text-sm font-bold tracking-tight text-slate-900 dark:text-white">
                      Satisfaction (1-10)
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={ratingSatisfaction}
                      onChange={(e) => setRatingSatisfaction(parseInt(e.target.value))}
                      className="w-full bg-slate-200/50 dark:bg-slate-800/50 h-2 rounded-lg cursor-pointer"
                      style={{ accentColor: 'var(--color-primary)' }}
                    />
                    <div className="flex justify-between text-xs text-slate-500 font-bold px-1">
                      <span>Dissatisfied</span>
                      <span className="text-primary font-black bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md font-mono">
                        Val: {ratingSatisfaction}
                      </span>
                      <span>Content</span>
                    </div>
                  </div>

                  {/* Emotional State */}
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                      Emotional State
                    </label>
                    <input
                      type="text"
                      value={emotionalState}
                      onChange={(e) => setEmotionalState(e.target.value)}
                      placeholder="e.g. Calm, FOMO, Focused"
                      className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all backdrop-blur-md"
                    />
                  </div>

                  {/* Lessons */}
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                      Lessons & Notes
                    </label>
                    <textarea
                      value={lessonsLearned}
                      onChange={(e) => setLessonsLearned(e.target.value)}
                      rows={3}
                      placeholder="Insights from this execution..."
                      className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-medium text-slate-900 dark:text-white text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 resize-none custom-scrollbar transition-all backdrop-blur-md"
                    ></textarea>
                  </div>
                </div>

                {/* Mistake Checklist */}
                <div className="bg-white/40 dark:bg-slate-900/40 p-6 rounded-2xl border border-white/50 dark:border-slate-700/50 backdrop-blur-md shadow-sm">
                  <h4 class="text-sm font-bold tracking-tight text-slate-900 dark:text-white mb-1">
                    Mistake Audit
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-5 font-medium">
                    Classify systemic behavioral risks
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm font-semibold text-slate-600 dark:text-slate-300">
                    {appConfig.mistakes.map((m) => (
                      <label key={m} className="flex items-center space-x-3 cursor-pointer group">
                        <input
                          type="checkbox"
                          checked={selectedMistakes.includes(m)}
                          onChange={() => handleMistakeToggle(m)}
                          className="rounded bg-white dark:bg-slate-900 border-slate-300/50 dark:border-slate-700/50 focus:ring-0 w-4 h-4 transition"
                          style={{ color: 'var(--color-primary)' }}
                        />
                        <span className="group-hover:text-slate-900 dark:group-hover:text-white transition">
                          {m}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Buttons Footer */}
          <div className="flex justify-end items-center gap-3 border-t border-white/30 dark:border-slate-800/60 pt-5 mt-2 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="bg-white/50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-700 text-slate-800 dark:text-white px-5 py-2.5 rounded-xl text-sm font-bold tracking-tight transition duration-300 border border-white/50 dark:border-slate-700/50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-primary hover:bg-primary-hover text-white px-8 py-2.5 rounded-xl text-sm font-bold tracking-tight transition duration-300 shadow-lg hover:-translate-y-0.5"
            >
              Commit Ledger Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
