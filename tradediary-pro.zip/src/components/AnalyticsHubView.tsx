import { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { Trade, AppConfig } from '../types';

interface AnalyticsHubViewProps {
  trades: Trade[];
  appConfig: AppConfig;
  colors: {
    primary: string;
    success: string;
    danger: string;
    tick: string;
  };
}

export default function AnalyticsHubView({ trades, appConfig, colors }: AnalyticsHubViewProps) {
  const [selectedStrategy, setSelectedStrategy] = useState<string>('ALL');

  // Filter trades based on selected strategy
  const filteredTrades =
    selectedStrategy === 'ALL'
      ? trades
      : trades.filter((t) => t.strategyTag === selectedStrategy);

  // 1. Math formulas for ratios
  const totalCount = filteredTrades.length;
  const wins = filteredTrades.filter((t) => (t.calculatedPl || 0) >= 0);
  const losses = filteredTrades.filter((t) => (t.calculatedPl || 0) < 0);
  const winCount = wins.length;
  const lossCount = losses.length;

  const grossWins = wins.reduce((acc, t) => acc + (t.calculatedPl || 0), 0);
  const grossLosses = losses.reduce((acc, t) => acc + Math.abs(t.calculatedPl || 0), 0);

  const avgWin = winCount > 0 ? grossWins / winCount : 0;
  const avgLoss = lossCount > 0 ? grossLosses / lossCount : 0;

  // Avg R:R
  const avgRr = avgLoss > 0 ? avgWin / avgLoss : 0;

  // Kelly Factor: W - (1 - W) / R
  const winRateFrac = totalCount > 0 ? winCount / totalCount : 0;
  let kellyFactor = 0;
  if (avgRr > 0) {
    kellyFactor = winRateFrac - (1 - winRateFrac) / avgRr;
  }

  // Sharpe Ratio: Mean / StdDev
  const returns = filteredTrades.map((t) => t.calculatedPl || 0);
  const meanReturn = totalCount > 0 ? returns.reduce((acc, r) => acc + r, 0) / totalCount : 0;

  let stdDev = 0;
  if (totalCount > 1) {
    const variance = returns.reduce((acc, r) => acc + Math.pow(r - meanReturn, 2), 0) / (totalCount - 1);
    stdDev = Math.sqrt(variance);
  }
  const sharpeRatio = stdDev > 0 ? meanReturn / stdDev : 0;

  // Max Drawdown (trough from peak equity)
  let maxDrawdown = 0;
  let runningEquity = 0;
  let peakEquity = 0;
  const chronTrades = [...filteredTrades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  chronTrades.forEach((t) => {
    runningEquity += t.calculatedPl || 0;
    if (runningEquity > peakEquity) {
      peakEquity = runningEquity;
    }
    const currentDrawdown = peakEquity - runningEquity;
    if (currentDrawdown > maxDrawdown) {
      maxDrawdown = currentDrawdown;
    }
  });

  // Day of Week Profile Calculations
  const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayProfileMap: { [key: string]: { pnl: number; count: number } } = {};
  weekdays.forEach((day) => {
    dayProfileMap[day] = { pnl: 0, count: 0 };
  });

  filteredTrades.forEach((t) => {
    if (!t.date) return;
    const d = new Date(t.date);
    const dayName = weekdays[d.getDay()];
    dayProfileMap[dayName].pnl += t.calculatedPl || 0;
    dayProfileMap[dayName].count++;
  });

  const dayProfileList = weekdays.map((day) => ({
    day,
    pnl: dayProfileMap[day].pnl,
    count: dayProfileMap[day].count,
  }));

  // Strategy Matrix breakdown table data
  const strategyStats = appConfig.strategies.map((strat) => {
    const stratTrades = trades.filter((t) => t.strategyTag === strat);
    const sWins = stratTrades.filter((t) => (t.calculatedPl || 0) >= 0).length;
    const sLosses = stratTrades.filter((t) => (t.calculatedPl || 0) < 0).length;
    const sTotal = stratTrades.length;
    const sWinRate = sTotal > 0 ? ((sWins / sTotal) * 100).toFixed(1) : '0.0';
    const sPnl = stratTrades.reduce((acc, t) => acc + (t.calculatedPl || 0), 0);

    return {
      name: strat,
      total: sTotal,
      wins: sWins,
      losses: sLosses,
      winRate: sWinRate,
      pnl: sPnl,
    };
  });

  // Recharts Strategy Alpha chart data
  const alphaChartData = strategyStats.filter((s) => s.total > 0).map((s) => ({
    name: s.name,
    pnl: s.pnl,
  }));

  return (
    <div className="tab-content animate-fade-in space-y-8">
      {/* Head Filter bar */}
      <div className="glass-panel flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl transition-all duration-300">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
            Analytics Hub & Strategy Audit
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium tracking-tight">
            Advanced actuarial profiles and systematic matrix analysis
          </p>
        </div>
        <div>
          <select
            value={selectedStrategy}
            onChange={(e) => setSelectedStrategy(e.target.value)}
            className="bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl px-4 py-2.5 text-sm text-slate-900 dark:text-white font-semibold focus:outline-none focus:border-primary cursor-pointer backdrop-blur-md transition-colors"
          >
            <option value="ALL">All Strategies</option>
            {appConfig.strategies.map((strat) => (
              <option key={strat} value={strat}>
                {strat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Advanced actuary metrics row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sharpe */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[140px] transition-all duration-300 hover:-translate-y-1">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Sharpe Ratio
            </p>
            <p className="text-3xl font-black font-mono mt-2 text-primary">{sharpeRatio.toFixed(2)}</p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Risk-adjusted return ratio
          </div>
        </div>

        {/* Kelly Criterion */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[140px] transition-all duration-300 hover:-translate-y-1">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Kelly Factor %
            </p>
            <p className="text-3xl font-black font-mono mt-2 text-purple-500 dark:text-purple-400">
              {(kellyFactor * 100).toFixed(1)}%
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Optimal position allocation size
          </div>
        </div>

        {/* Max Drawdown */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[140px] transition-all duration-300 hover:-translate-y-1">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Max Drawdown (₹)
            </p>
            <p className="text-3xl font-black font-mono mt-2 text-rose-500 dark:text-rose-400">
              ₹{maxDrawdown.toFixed(0)}
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Worst peak-to-trough drop
          </div>
        </div>

        {/* Strategy R:R */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[140px] transition-all duration-300 hover:-translate-y-1">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Strategy R:R Avg
            </p>
            <p className="text-3xl font-black font-mono mt-2 text-emerald-500 dark:text-emerald-400">
              1:{avgRr.toFixed(2)}
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Strategy win-loss size ratio
          </div>
        </div>
      </div>

      {/* Row 3: Alpha chart & Day-of-week profile */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Strategy Alpha chart */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">
            Strategy Alpha (PnL returns)
          </h3>
          <div className="h-64">
            {alphaChartData.length === 0 ? (
              <div className="text-xs text-slate-500 font-bold uppercase tracking-widest text-center mt-12">
                No custom strategy alpha loaded
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={alphaChartData}>
                  <XAxis dataKey="name" stroke={colors.tick} tickLine={false} fontSize={11} />
                  <YAxis stroke={colors.tick} tickLine={false} fontSize={11} />
                  <Tooltip
                    cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#f8fafc',
                    }}
                  />
                  <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                    {alphaChartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.pnl >= 0 ? colors.success : colors.danger}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Day-of-week profile list */}
        <div className="glass-panel rounded-2xl overflow-hidden shadow-sm flex flex-col transition-all duration-300">
          <div className="px-6 py-4 border-b border-white/20 dark:border-slate-800/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
              Day-of-Week Profile
            </h3>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100/50 dark:bg-slate-900/50 border-b border-slate-200/50 dark:border-slate-800/50 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                  <th className="px-6 py-4">Day of Week</th>
                  <th className="px-6 py-4">Execution Volume</th>
                  <th className="px-6 py-4">Net Return Sum</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/50 dark:divide-slate-800/50 text-sm font-semibold text-slate-700 dark:text-slate-300">
                {dayProfileList.map((row) => (
                  <tr
                    key={row.day}
                    className="hover:bg-white/50 dark:hover:bg-slate-900/40 transition-colors text-xs font-semibold text-slate-700 dark:text-slate-300"
                  >
                    <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">{row.day}</td>
                    <td className="px-6 py-4 font-mono">{row.count} items run</td>
                    <td className={`px-6 py-4 font-mono ${row.pnl >= 0 ? 'text-emerald-500' : 'text-rose-500'} font-bold`}>
                      {row.pnl >= 0 ? '+' : ''}₹{row.pnl.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Strategy statistics breakdown table */}
      <div className="glass-panel rounded-2xl overflow-hidden shadow-sm transition-all duration-300">
        <div className="px-6 py-4 border-b border-white/20 dark:border-slate-800/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
            Setup Strategy Statistics Matrix
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/50 dark:bg-slate-900/50 border-b border-slate-200/50 dark:border-slate-800/50 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                <th className="px-6 py-4">Strategy Setup</th>
                <th className="px-6 py-4">Total Trades</th>
                <th className="px-6 py-4">Wins</th>
                <th className="px-6 py-4">Losses</th>
                <th className="px-6 py-4">Win Rate %</th>
                <th className="px-6 py-4">Net Strategy Return</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/50 dark:divide-slate-800/50 text-sm font-medium">
              {strategyStats.length === 0 ? (
                <tr>
                  <td
                    colSpan={6}
                    className="px-6 py-12 text-center text-xs font-bold tracking-widest uppercase text-slate-500"
                  >
                    No strategy tags loaded.
                  </td>
                </tr>
              ) : (
                strategyStats.map((row) => (
                  <tr
                    key={row.name}
                    className="hover:bg-white/50 dark:hover:bg-slate-900/40 transition-colors text-xs font-semibold text-slate-700 dark:text-slate-300"
                  >
                    <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">
                      {row.name}
                    </td>
                    <td className="px-6 py-4 font-mono">{row.total}</td>
                    <td className="px-6 py-4 text-emerald-500 font-bold">{row.wins}</td>
                    <td className="px-6 py-4 text-rose-500 font-bold">{row.losses}</td>
                    <td className="px-6 py-4 font-mono">{row.winRate}%</td>
                    <td className={`px-6 py-4 font-mono ${row.pnl >= 0 ? 'text-emerald-500' : 'text-rose-500'} font-bold`}>
                      {row.pnl >= 0 ? '+' : ''}₹{row.pnl.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
