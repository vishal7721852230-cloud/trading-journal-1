import { useState } from 'react';
import { DollarSign, Target, Activity, BarChart2, Search, Image as ImageIcon, Edit3, Trash } from 'lucide-react';
import { Trade, AppConfig } from '../types';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
} from 'recharts';

interface DashboardViewProps {
  trades: Trade[];
  appConfig: AppConfig;
  onEditTrade: (index: number) => void;
  onRemoveTrade: (index: number) => void;
  onViewImage: (image: string) => void;
  colors: {
    grid: string;
    tick: string;
    primary: string;
    success: string;
    danger: string;
  };
}

export default function DashboardView({
  trades,
  appConfig,
  onEditTrade,
  onRemoveTrade,
  onViewImage,
  colors,
}: DashboardViewProps) {
  const [searchQuery, setSearchQuery] = useState('');

  // 1. Core analytics
  let totalPl = 0;
  let wins = 0;
  let losses = 0;
  let maxWinStreak = 0;
  let maxLossStreak = 0;
  let workingWinStreak = 0;
  let workingLossStreak = 0;

  // Sorting trades chronologically for curve calculations
  const chronTrades = [...trades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const equityData: { name: string; value: number }[] = [];
  const streakData: { name: string; value: number }[] = [];

  let runningEquity = 0;
  let runningStreak = 0;

  chronTrades.forEach((t, i) => {
    const pl = t.calculatedPl || 0;
    totalPl += pl;
    runningEquity += pl;

    if (pl >= 0) {
      wins++;
      workingWinStreak++;
      maxLossStreak = Math.max(maxLossStreak, workingLossStreak);
      workingLossStreak = 0;
      runningStreak++;
    } else {
      losses++;
      workingLossStreak++;
      maxWinStreak = Math.max(maxWinStreak, workingWinStreak);
      workingWinStreak = 0;
      runningStreak = 0; // reset streak on loss
    }

    equityData.push({ name: `T${i + 1}`, value: runningEquity });
    streakData.push({ name: `T${i + 1}`, value: runningStreak });
  });

  maxWinStreak = Math.max(maxWinStreak, workingWinStreak);
  maxLossStreak = Math.max(maxLossStreak, workingLossStreak);

  // Win Rate
  const winRate = wins + losses > 0 ? (wins / (wins + losses)) * 100 : 0;

  // Risk/Reward (Global Average return profile)
  const grossLosses = trades.filter((t) => (t.calculatedPl || 0) < 0).reduce((acc, curr) => acc + Math.abs(curr.calculatedPl || 0), 0);
  const grossWins = trades.filter((t) => (t.calculatedPl || 0) >= 0).reduce((acc, curr) => acc + (curr.calculatedPl || 0), 0);
  const avgLoss = losses > 0 ? grossLosses / losses : 0;
  const avgWin = wins > 0 ? grossWins / wins : 0;
  const rrRatio = avgLoss > 0 ? (avgWin / avgLoss).toFixed(2) : '0.00';

  // Strategy distribution data
  const strategyMap: { [key: string]: number } = {};
  trades.forEach((t) => {
    const strat = t.strategyTag || 'Unassigned';
    strategyMap[strat] = (strategyMap[strat] || 0) + (t.calculatedPl || 0);
  });
  const strategyData = Object.keys(strategyMap).map((strat) => ({
    name: strat,
    value: strategyMap[strat],
  }));

  // Mistakes Radar Data
  const mistakeMap: { [key: string]: number } = {};
  appConfig.mistakes.forEach((m) => {
    mistakeMap[m] = 0;
  });
  trades.forEach((t) => {
    if (t.mistakesMade && Array.isArray(t.mistakesMade)) {
      t.mistakesMade.forEach((m) => {
        if (mistakeMap.hasOwnProperty(m)) {
          mistakeMap[m]++;
        }
      });
    }
  });
  const mistakeRadarData = Object.keys(mistakeMap).map((m) => ({
    subject: m,
    value: mistakeMap[m],
  }));

  // Market Sentiment Gauge Level & Labels
  let sentimentLabel = 'NEUTRAL POSITION';
  let sentimentClass = 'text-xs font-bold text-slate-400 tracking-wide uppercase';
  if (winRate >= 60 && totalPl >= 0) {
    sentimentLabel = 'STRONG BULLISH';
    sentimentClass = 'text-xs font-black text-emerald-400 tracking-widest uppercase animate-pulse';
  } else if (winRate >= 45 && totalPl >= 0) {
    sentimentLabel = 'MODERATE BULLISH';
    sentimentClass = 'text-xs font-bold text-emerald-500/80 tracking-wide uppercase';
  } else if (winRate > 0 || totalPl < 0) {
    sentimentLabel = 'BEARISH RISK RISK';
    sentimentClass = 'text-xs font-black text-rose-500 tracking-wider uppercase';
  }

  // Filtered trades list (latest first)
  const filteredTrades = searchQuery
    ? trades.filter((t) => t.symbol.toLowerCase().includes(searchQuery.toLowerCase()))
    : trades;

  const reversedFilteredTrades = [...filteredTrades].reverse();

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Top 5 Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
        {/* Card 1: Net P&L Balance */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[145px] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_30px_-5px_rgba(16,185,129,0.3)] hover:border-emerald-500/30 group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Net P&L Balance
              </p>
              <p
                className={`text-2xl font-black font-mono mt-2 ${
                  totalPl >= 0 ? 'text-emerald-500 dark:text-emerald-400' : 'text-rose-500 dark:text-rose-400'
                }`}
              >
                ₹{totalPl.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
            <div className="bg-emerald-100 dark:bg-emerald-500/10 p-2.5 rounded-xl text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform duration-300">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-xs font-semibold text-emerald-500 dark:text-emerald-400 tracking-tight">
              +Active <span className="text-slate-500 font-medium">ledger tracking</span>
            </p>
          </div>
        </div>

        {/* Card 2: Win Rate */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[145px] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_30px_-5px_rgba(99,102,241,0.3)] hover:border-primary/30 group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Win Rate
              </p>
              <p className="text-2xl font-black font-mono mt-2 text-primary">{winRate.toFixed(1)}%</p>
            </div>
            <div className="bg-primary/10 p-2.5 rounded-xl text-primary group-hover:scale-110 transition-transform duration-300">
              <Target className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 w-full bg-slate-200 dark:bg-slate-800/50 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-primary h-full rounded-full transition-all duration-1000 ease-out"
              style={{ width: `${winRate}%` }}
            ></div>
          </div>
        </div>

        {/* Card 3: Risk/Reward */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[145px] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_30px_-5px_rgba(168,85,247,0.3)] hover:border-purple-500/30 group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Risk/Reward
              </p>
              <p className="text-2xl font-black font-mono mt-2 text-purple-500 dark:text-purple-400">1:{rrRatio}</p>
            </div>
            <div className="bg-purple-100 dark:bg-purple-500/10 p-2.5 rounded-xl text-purple-600 dark:text-purple-400 group-hover:scale-110 transition-transform duration-300">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 tracking-tight">
              Global Average Return Profile
            </p>
          </div>
        </div>

        {/* Card 4: Total Trades */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-between min-h-[145px] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_30px_-5px_rgba(245,158,11,0.3)] hover:border-amber-500/30 group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Total Trades
              </p>
              <p className="text-2xl font-black font-mono mt-2 text-amber-500 dark:text-amber-400">
                {trades.length}
              </p>
            </div>
            <div className="bg-amber-100 dark:bg-amber-500/10 p-2.5 rounded-xl text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform duration-300">
              <BarChart2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 tracking-tight">
              Historical Volume
            </p>
          </div>
        </div>

        {/* Card 5: Market Sentiment Gauge */}
        <div className="glass-panel rounded-2xl p-6 relative flex flex-col justify-center min-h-[145px] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_30px_-5px_var(--color-primary-hover)] hover:border-primary/30 text-center group">
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
            My Market Sentiment
          </p>
          <div className="relative h-16 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height={100}>
              <PieChart margin={{ top: 0, bottom: 0, left: 0, right: 0 }}>
                <Pie
                  data={[
                    { name: 'Sentiment', value: winRate || 0.1 },
                    { name: 'Bounds', value: 100 - (winRate || 0.1) },
                  ]}
                  startAngle={180}
                  endAngle={0}
                  innerRadius={30}
                  outerRadius={45}
                  dataKey="value"
                  stroke="none"
                >
                  <Cell fill={winRate >= 45 ? colors.success : colors.danger} />
                  <Cell fill="rgba(148, 163, 184, 0.1)" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex items-end justify-center pb-2">
              <span className={sentimentClass}>{sentimentLabel}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Charts (Win/Loss & Strategy vs PnL) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Win/Loss Distribution */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col justify-between min-h-[360px] transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">
            Win/Loss Distribution
          </h3>
          <div className="relative h-56 flex items-center justify-center my-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[
                    { name: 'Wins', value: wins },
                    { name: 'Losses', value: losses },
                  ]}
                  innerRadius="70%"
                  outerRadius="90%"
                  dataKey="value"
                  stroke="none"
                >
                  <Cell fill={colors.success} />
                  <Cell fill={colors.danger} />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-3xl font-black font-mono text-slate-900 dark:text-white drop-shadow-md">
                {winRate.toFixed(1)}%
              </span>
              <span className="text-[10px] font-bold tracking-widest text-slate-500 dark:text-slate-400 uppercase mt-1">
                Win Rate
              </span>
            </div>
          </div>
          <div className="flex justify-center items-center gap-12 border-t border-slate-200/50 dark:border-slate-800/50 pt-5 mt-2">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></span>
                <span className="text-xl font-black font-mono text-slate-900 dark:text-white">{wins}</span>
              </div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500">Wins</span>
            </div>
            <div className="border-l border-slate-300/50 dark:border-slate-700/50 h-8"></div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.8)]"></span>
                <span className="text-xl font-black font-mono text-slate-900 dark:text-white">{losses}</span>
              </div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500">Losses</span>
            </div>
          </div>
        </div>

        {/* Chart 2: Strategy vs P&L */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col justify-between min-h-[360px] transition-all duration-300">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
              Strategy vs P&L
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium tracking-tight mt-1">
              Performance outcome weighted across custom parameters
            </p>
          </div>
          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={strategyData}>
                <XAxis dataKey="name" stroke={colors.tick} tickLine={false} fontSize={11} />
                <YAxis stroke={colors.tick} tickLine={false} fontSize={11} />
                <Tooltip
                  cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#f8fafc',
                  }}
                />
                <Bar dataKey="value" fill={colors.primary} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 3: Advanced Charts (Equity Curve, Growth Streak, Mistakes) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Equity Chart */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">
            Equity Curve
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={equityData}>
                <defs>
                  <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={colors.primary} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={colors.primary} stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" hide />
                <YAxis stroke={colors.tick} tickLine={false} fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#f8fafc',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke={colors.primary}
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#equityGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Growth Streak Chart */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">
            Growth Streak
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={streakData}>
                <defs>
                  <linearGradient id="streakGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a855f7" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#a855f7" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" hide />
                <YAxis stroke={colors.tick} tickLine={false} fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#f8fafc',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#a855f7"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#streakGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mistakes Matrix Radar Chart */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">
            Mistake Matrix
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={mistakeRadarData}>
                <PolarGrid stroke={colors.grid} />
                <PolarAngleAxis dataKey="subject" tick={{ fill: colors.tick, fontSize: 8 }} />
                <Radar
                  name="Audit Frequency"
                  dataKey="value"
                  stroke={colors.danger}
                  fill={colors.danger}
                  fillOpacity={0.25}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Historical logs table */}
      <div className="glass-panel rounded-2xl overflow-hidden shadow-sm transition-all duration-300">
        <div className="px-6 py-4 border-b border-white/20 dark:border-slate-800/50 bg-white/40 dark:bg-slate-900/40 flex justify-between items-center backdrop-blur-md">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
            Historical Transaction Logs
          </h3>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="w-4 h-4 text-slate-400" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Ticker..."
              className="bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 text-slate-900 dark:text-white text-xs rounded-lg focus-visible:ring-primary focus-visible:border-primary block w-full pl-9 p-2 transition-all outline-none backdrop-blur-sm"
            />
          </div>
        </div>
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto custom-scrollbar">
          <table className="w-full text-left border-collapse relative">
            <thead className="sticky top-0 z-10">
              <tr className="bg-slate-100/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/50 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest shadow-sm">
                <th className="px-6 py-4">Asset</th>
                <th className="px-6 py-4">Direction</th>
                <th className="px-6 py-4">Env / Strategy</th>
                <th className="px-6 py-4">Risk Matrix</th>
                <th className="px-6 py-4">Attachment</th>
                <th className="px-6 py-4">Psychology</th>
                <th className="px-6 py-4">Net P&L</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/50 dark:divide-slate-800/50 text-sm">
              {reversedFilteredTrades.length === 0 ? (
                <tr>
                  <td colspan={8} className="px-6 py-12 text-center text-xs font-bold tracking-widest uppercase text-slate-500">
                    No corresponding logs match current filters.
                  </td>
                </tr>
              ) : (
                reversedFilteredTrades.map((t) => {
                  const plValue = t.calculatedPl || 0;
                  const plSign = plValue >= 0 ? '+' : '';
                  const tSign = t.currency === 'USD' ? '$' : '₹';

                  // Original actual index in `trades`
                  const originalIndex = trades.indexOf(t);

                  return (
                    <tr
                      key={originalIndex}
                      className="hover:bg-white/40 dark:hover:bg-slate-900/40 transition duration-200 text-slate-700 dark:text-slate-300 border-b border-slate-200/50 dark:border-slate-800/50 font-medium"
                    >
                      <td className="px-6 py-4">
                        <div className="font-black text-slate-900 dark:text-white tracking-wide text-base">
                          {t.symbol}
                        </div>
                        <div className="text-[10px] font-bold text-slate-400 mt-0.5">{t.date}</div>
                      </td>
                      <td className="px-6 py-4">
                        {t.direction === 'SHORT' ? (
                          <span className="px-2.5 py-1 text-[10px] font-extrabold tracking-wider bg-purple-100 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-lg border border-purple-200 dark:border-purple-500/20">
                            SHORT
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 text-[10px] font-extrabold tracking-wider bg-primary/10 text-primary rounded-lg border border-primary/20">
                            LONG
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {t.strategyTag}
                        </div>
                        <div className="text-[10px] font-medium text-slate-400 uppercase tracking-wider mt-0.5">
                          {t.marketCondition}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-[11px] text-slate-400 font-mono">
                          <div>
                            Ent: {tSign}
                            {t.entryPrice.toFixed(2)}
                          </div>
                          <div>Qty: {t.quantity}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {t.chartImage ? (
                          <button
                            onClick={() => onViewImage(t.chartImage)}
                            className="text-primary hover:text-primary-hover flex items-center gap-1 text-xs font-bold transition hover:underline"
                          >
                            <ImageIcon className="w-3.5 h-3.5" /> Layout
                          </button>
                        ) : (
                          <span className="text-slate-400 text-xs">None</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-[11px] space-y-0.5">
                          <div className="text-slate-500 dark:text-slate-400 font-semibold">
                            <span className="text-[10px] text-slate-400">Feel:</span>{' '}
                            {t.emotionalState || 'Calm'}
                          </div>
                          <div
                            className="text-slate-400 truncate max-w-[140px]"
                            title={t.lessonsLearned}
                          >
                            {t.lessonsLearned}
                          </div>
                        </div>
                      </td>
                      <td className={`px-6 py-4 font-mono text-sm ${plValue >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                        {plSign}
                        {tSign}
                        {plValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => onEditTrade(originalIndex)}
                            className="p-1.5 text-slate-400 hover:text-primary hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                            title="Modify parameters"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onRemoveTrade(originalIndex)}
                            className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                            title="Purge Record"
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
