import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Trade } from '../types';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (trade: Trade) => void;
  onDetailedEntry: () => void;
  defaultEcosystem: string;
}

export default function QuickAddModal({
  isOpen,
  onClose,
  onAdd,
  onDetailedEntry,
  defaultEcosystem,
}: QuickAddModalProps) {
  const [symbol, setSymbol] = useState('');
  const [pnl, setPnl] = useState('');
  const [direction, setDirection] = useState<'LONG' | 'SHORT'>('LONG');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!symbol) return;

    const pnlNum = parseFloat(pnl) || 0;

    const newTrade: Trade = {
      date: new Date().toISOString().split('T')[0],
      symbol: symbol.toUpperCase().trim(),
      marketCondition: defaultEcosystem || 'Indian Market',
      currency: 'INR',
      entryPrice: 0,
      quantity: 1,
      exitPrice: 0,
      stopLossPrice: 0,
      targetPrice: 0,
      manualPnlAmount: pnlNum,
      calculatedPl: pnlNum,
      direction: direction,
      tradeDuration: 'INTRADAY',
      strategyTag: 'Quick Entry',
      tradeStatus: pnlNum >= 0 ? 'WIN' : 'LOSS',
      ratingConfidence: 5,
      ratingSatisfaction: 5,
      emotionalState: 'Calm',
      lessonsLearned: 'Logged via Quick Execution engine.',
      mistakesMade: pnlNum >= 0 ? ['No Mistakes'] : [],
      chartImage: '',
    };

    onAdd(newTrade);
    setSymbol('');
    setPnl('');
    setDirection('LONG');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 dark:bg-slate-950/60 backdrop-blur-xl flex items-center justify-center z-[70] p-4 transition-all">
      <div className="glass-panel w-full max-w-sm rounded-3xl p-8 shadow-2xl relative border-white/40 dark:border-slate-700/50 transform scale-100 transition-all animate-fade-in">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition duration-300"
        >
          <X className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white mb-1">Quick Execution</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 font-medium">Log a rapid trade entry instantly.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
              Symbol / Asset
            </label>
            <input
              type="text"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              placeholder="e.g. BTCUSDT"
              className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-semibold text-slate-900 dark:text-white uppercase focus:border-primary focus:ring-2 focus:ring-primary/30 outline-none transition-all backdrop-blur-md"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                Net P&L Balance
              </label>
              <input
                type="number"
                step="any"
                value={pnl}
                onChange={(e) => setPnl(e.target.value)}
                placeholder="0.00"
                className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-mono font-semibold text-slate-900 dark:text-white focus:border-primary focus:ring-2 focus:ring-primary/30 outline-none transition-all backdrop-blur-md"
                required
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                Direction
              </label>
              <select
                value={direction}
                onChange={(e) => setDirection(e.target.value as 'LONG' | 'SHORT')}
                className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 font-semibold text-slate-900 dark:text-white focus:border-primary focus:ring-2 focus:ring-primary/30 outline-none transition-all cursor-pointer backdrop-blur-md"
              >
                <option value="LONG">LONG</option>
                <option value="SHORT">SHORT</option>
              </select>
            </div>
          </div>
          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary-hover text-white font-bold tracking-tight py-3.5 rounded-xl shadow-lg transition-all duration-300 mt-2 hover:-translate-y-0.5"
          >
            Log Fast Trade
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onDetailedEntry();
            }}
            className="w-full text-xs text-primary font-bold py-2 mt-1 transition-colors"
          >
            Open Detailed Form Instead →
          </button>
        </form>
      </div>
    </div>
  );
}
