import React, { useState, useEffect } from 'react';
import { Sliders, X } from 'lucide-react';
import { AppConfig } from '../types';

interface CustomizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  appConfig: AppConfig;
  onSave: (newConfig: AppConfig) => void;
  onRestore: () => void;
}

export default function CustomizationModal({
  isOpen,
  onClose,
  appConfig,
  onSave,
  onRestore,
}: CustomizationModalProps) {
  const [brandName, setBrandName] = useState('');
  const [font, setFont] = useState('');
  const [primaryColor, setPrimaryColor] = useState('');
  const [successColor, setSuccessColor] = useState('');
  const [dangerColor, setDangerColor] = useState('');
  const [bgLight, setBgLight] = useState('');
  const [bgDark, setBgDark] = useState('');
  const [bg, setBg] = useState<'mesh' | 'solid' | 'gradient'>('mesh');
  const [palette, setPalette] = useState<'default' | 'neon' | 'pastel' | 'warm' | 'monochrome'>('default');
  const [chartGridColor, setChartGridColor] = useState('');

  const [strategiesStr, setStrategiesStr] = useState('');
  const [ecosystemsStr, setEcosystemsStr] = useState('');
  const [outcomesStr, setOutcomesStr] = useState('');
  const [mistakesStr, setMistakesStr] = useState('');

  // Sync state with incoming config
  useEffect(() => {
    if (isOpen) {
      setBrandName(appConfig.brandName);
      setFont(appConfig.theme.font);
      setPrimaryColor(appConfig.theme.primaryColor);
      setSuccessColor(appConfig.theme.successColor);
      setDangerColor(appConfig.theme.dangerColor);
      setBgLight(appConfig.theme.bgLight);
      setBgDark(appConfig.theme.bgDark);
      setBg(appConfig.theme.bg);
      setPalette(appConfig.theme.palette);
      setChartGridColor(appConfig.theme.chartGridColor || '');

      setStrategiesStr(appConfig.strategies.join(', '));
      setEcosystemsStr(appConfig.ecosystems.join(', '));
      setOutcomesStr(appConfig.outcomes.join(', '));
      setMistakesStr(appConfig.mistakes.join(', '));
    }
  }, [isOpen, appConfig]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const parseList = (str: string) =>
      str
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

    const updatedConfig: AppConfig = {
      brandName: brandName.trim(),
      strategies: parseList(strategiesStr),
      ecosystems: parseList(ecosystemsStr),
      outcomes: parseList(outcomesStr),
      mistakes: parseList(mistakesStr),
      theme: {
        primaryColor,
        successColor,
        dangerColor,
        bgLight,
        bgDark,
        bg,
        font,
        palette,
        chartGridColor,
      },
    };

    onSave(updatedConfig);
    onClose();
  };

  const handleResetChartGrid = () => {
    const isDark = document.documentElement.classList.contains('dark');
    setChartGridColor(isDark ? '#334155' : '#e2e8f0');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 dark:bg-slate-950/60 backdrop-blur-xl flex items-center justify-center z-[90] p-4 overflow-y-auto transition-all">
      <div className="glass-panel w-full max-w-4xl rounded-3xl p-6 shadow-2xl relative border-white/40 dark:border-slate-700/50 transform scale-100 transition-all animate-fade-in my-8">
        <div className="flex justify-between items-center mb-6 border-b border-white/30 dark:border-slate-800/60 pb-4">
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Sliders className="text-primary w-6 h-6" /> Customization Setup Engine
          </h2>
          <button
            onClick={onClose}
            className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition duration-300"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          {/* Typography & Branding */}
          <div className="bg-white/40 dark:bg-slate-900/40 p-5 rounded-2xl border border-white/50 dark:border-slate-700/50 backdrop-blur-md space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest border-b border-slate-200/50 dark:border-slate-800 pb-2">
              1. Typography & Branding
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Journal Title (Brand Name)
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-2.5 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Primary Font Family
                </label>
                <select
                  value={font}
                  onChange={(e) => setFont(e.target.value)}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-2.5 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary backdrop-blur-md"
                >
                  <option value='"Plus Jakarta Sans"'>Plus Jakarta Sans</option>
                  <option value='"Inter"'>Inter</option>
                  <option value='"Poppins"'>Poppins</option>
                  <option value='"Playfair Display"'>Playfair Display</option>
                  <option value='"JetBrains Mono"'>JetBrains Mono (Monospace)</option>
                  <option value='"Roboto Mono"'>Roboto Mono (Monospace)</option>
                  <option value="system-ui">System UI Default</option>
                </select>
              </div>
            </div>
          </div>

          {/* Visual Themes & Colors */}
          <div className="bg-white/40 dark:bg-slate-900/40 p-5 rounded-2xl border border-white/50 dark:border-slate-700/50 backdrop-blur-md space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest border-b border-slate-200/50 dark:border-slate-800 pb-2">
              2. Visual Themes & Colors
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Accent Color
                </label>
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-slate-300/50 dark:border-slate-700/50 p-1"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Win/Success
                </label>
                <input
                  type="color"
                  value={successColor}
                  onChange={(e) => setSuccessColor(e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-slate-300/50 dark:border-slate-700/50 p-1"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Loss/Danger
                </label>
                <input
                  type="color"
                  value={dangerColor}
                  onChange={(e) => setDangerColor(e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-slate-300/50 dark:border-slate-700/50 p-1"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Light Mode BG
                </label>
                <input
                  type="color"
                  value={bgLight}
                  onChange={(e) => setBgLight(e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-slate-300/50 dark:border-slate-700/50 p-1"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Dark Mode BG
                </label>
                <input
                  type="color"
                  value={bgDark}
                  onChange={(e) => setBgDark(e.target.value)}
                  className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-slate-300/50 dark:border-slate-700/50 p-1"
                />
              </div>
            </div>
          </div>

          {/* Background Style & Chart Settings */}
          <div className="bg-white/40 dark:bg-slate-900/40 p-5 rounded-2xl border border-white/50 dark:border-slate-700/50 backdrop-blur-md space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest border-b border-slate-200/50 dark:border-slate-800 pb-2">
              3. Background Style & Chart Settings
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Background Style
                </label>
                <select
                  value={bg}
                  onChange={(e) => setBg(e.target.value as 'mesh' | 'solid' | 'gradient')}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-2.5 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary backdrop-blur-md"
                >
                  <option value="mesh">Dot Mesh Overlay (Default)</option>
                  <option value="solid">Solid Minimalist Color</option>
                  <option value="gradient">Glassy Fluid Gradient</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Allocation Chart Preset
                </label>
                <select
                  value={palette}
                  onChange={(e) => setPalette(e.target.value as 'default' | 'neon' | 'pastel' | 'warm' | 'monochrome')}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-2.5 font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary backdrop-blur-md"
                >
                  <option value="default">Classic Spectrum</option>
                  <option value="neon">Cyberpunk Neon</option>
                  <option value="pastel">Pastel Softness</option>
                  <option value="warm">Warm Sunset</option>
                  <option value="monochrome">Monochromatic Steps</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Chart Grid Line Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={chartGridColor}
                    onChange={(e) => setChartGridColor(e.target.value)}
                    className="h-10 w-16 rounded-xl cursor-pointer bg-transparent border border-slate-300/50 dark:border-slate-700/50 p-1"
                  />
                  <button
                    type="button"
                    onClick={handleResetChartGrid}
                    className="text-xs bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 px-3 py-2 rounded-xl transition"
                  >
                    Use Default
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Trading Journal Data Fields */}
          <div className="bg-white/40 dark:bg-slate-900/40 p-5 rounded-2xl border border-white/50 dark:border-slate-700/50 backdrop-blur-md space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest border-b border-slate-200/50 dark:border-slate-800 pb-2">
              4. Trading Journal Data Fields
            </h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Enter multiple items separated by commas.</p>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Setup Tags / Strategies
                </label>
                <textarea
                  value={strategiesStr}
                  onChange={(e) => setStrategiesStr(e.target.value)}
                  rows={2}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary resize-none backdrop-blur-md"
                ></textarea>
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Ecosystems / Markets
                </label>
                <input
                  type="text"
                  value={ecosystemsStr}
                  onChange={(e) => setEcosystemsStr(e.target.value)}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary backdrop-blur-md"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Outcome Summary (First part determines Win/Loss logic)
                </label>
                <input
                  type="text"
                  value={outcomesStr}
                  onChange={(e) => setOutcomesStr(e.target.value)}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary backdrop-blur-md"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5 ml-1">
                  Mistake Audit Types
                </label>
                <textarea
                  value={mistakesStr}
                  onChange={(e) => setMistakesStr(e.target.value)}
                  rows={2}
                  className="w-full bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl p-3 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-primary resize-none backdrop-blur-md"
                ></textarea>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <button
              type="button"
              onClick={() => {
                if (confirm('Restore defaults?')) {
                  onRestore();
                  onClose();
                }
              }}
              className="text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-500/20 border border-transparent hover:border-rose-300 px-4 py-2 rounded-xl text-xs font-bold transition"
            >
              Restore Factory Theme
            </button>
            <button
              type="submit"
              className="bg-primary hover:bg-primary-hover text-white px-8 py-3 rounded-xl text-sm font-bold tracking-tight transition duration-300 shadow-lg hover:-translate-y-0.5"
            >
              Save Dynamic Preferences
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
