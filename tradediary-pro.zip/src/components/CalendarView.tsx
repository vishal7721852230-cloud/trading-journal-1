import { useState } from 'react';
import { Trade, AppConfig } from '../types';

interface CalendarViewProps {
  trades: Trade[];
  appConfig: AppConfig;
}

export default function CalendarView({ trades, appConfig }: CalendarViewProps) {
  const currentObj = new Date();
  const [targetMonth, setTargetMonth] = useState<number>(currentObj.getMonth());
  const [targetYear, setTargetYear] = useState<number>(currentObj.getFullYear());
  const [targetMarket, setTargetMarket] = useState<string>('ALL');

  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  // List of years (current year - 3 to current year + 2)
  const baseYear = currentObj.getFullYear();
  const years = Array.from({ length: 6 }, (_, idx) => baseYear - 3 + idx);

  // Map trades for the selected month, year, and ecosystem
  const calendarMap: { [day: number]: { pnl: number; count: number; currency: 'INR' | 'USD' } } = {};

  trades.forEach((t) => {
    if (!t.date) return;
    const dObj = new Date(t.date);
    if (dObj.getFullYear() !== targetYear || dObj.getMonth() !== targetMonth) return;
    if (targetMarket !== 'ALL' && t.marketCondition !== targetMarket) return;

    const dayKey = dObj.getDate();
    if (!calendarMap[dayKey]) {
      calendarMap[dayKey] = { pnl: 0, count: 0, currency: t.currency || 'INR' };
    }
    calendarMap[dayKey].pnl += t.calculatedPl || 0;
    calendarMap[dayKey].count++;
  });

  // Calendar calculations
  const firstDayIndex = new Date(targetYear, targetMonth, 1).getDay();
  const daysInMonthTotal = new Date(targetYear, targetMonth + 1, 0).getDate();

  const emptyCells = Array.from({ length: firstDayIndex });
  const dayCells = Array.from({ length: daysInMonthTotal }, (_, i) => i + 1);

  return (
    <div className="tab-content animate-fade-in space-y-6">
      {/* Filters Head */}
      <div className="glass-panel flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl transition-all duration-300">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
            Performance Calendar
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium tracking-tight">
            Dynamic daily strategy outcome log
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={targetMarket}
            onChange={(e) => setTargetMarket(e.target.value)}
            className="bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl px-4 py-2 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-primary cursor-pointer backdrop-blur-md transition-colors"
          >
            <option value="ALL">All Environments</option>
            {appConfig.ecosystems.map((eco) => (
              <option key={eco} value={eco}>
                {eco}
              </option>
            ))}
          </select>
          <select
            value={targetMonth}
            onChange={(e) => setTargetMonth(parseInt(e.target.value))}
            className="bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl px-4 py-2 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-primary cursor-pointer backdrop-blur-md transition-colors"
          >
            {months.map((m, idx) => (
              <option key={m} value={idx}>
                {m}
              </option>
            ))}
          </select>
          <select
            value={targetYear}
            onChange={(e) => setTargetYear(parseInt(e.target.value))}
            className="bg-white/70 dark:bg-slate-900/70 border border-slate-300/50 dark:border-slate-700/50 rounded-xl px-4 py-2 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-primary cursor-pointer backdrop-blur-md transition-colors"
          >
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Calendar body */}
      <div className="glass-panel rounded-2xl p-6 space-y-4 transition-all duration-300">
        <div className="grid grid-cols-7 text-center font-bold text-[11px] tracking-widest uppercase text-slate-500 pb-4 border-b border-slate-200/50 dark:border-slate-800/50">
          <div>Sun</div>
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
        </div>
        <div className="grid grid-cols-7 gap-3 font-sans">
          {emptyCells.map((_, idx) => (
            <div
              key={`empty-${idx}`}
              className="bg-slate-100/30 dark:bg-slate-900/20 border border-slate-200/50 dark:border-slate-800/30 min-h-[90px] rounded-xl backdrop-blur-sm"
            ></div>
          ))}

          {dayCells.map((day) => {
            const metrics = calendarMap[day];
            let dynamicDataHTML = null;
            let classSty = 'bg-white/50 dark:bg-slate-900/50 border border-white/50 dark:border-slate-700/50 backdrop-blur-md';

            if (metrics) {
              const signSymbol = metrics.pnl >= 0 ? '+' : '';
              const sign = metrics.currency === 'USD' ? '$' : '₹';
              const textColor =
                metrics.pnl >= 0
                  ? 'text-emerald-500 dark:text-emerald-400 font-bold'
                  : 'text-rose-500 dark:text-rose-400 font-bold';

              classSty =
                metrics.pnl >= 0
                  ? 'bg-emerald-50/70 dark:bg-emerald-900/30 border border-emerald-200/50 dark:border-emerald-800/50 backdrop-blur-md shadow-[inset_0_0_15px_rgba(16,185,129,0.05)] font-bold'
                  : 'bg-rose-50/70 dark:bg-rose-900/30 border border-rose-200/50 dark:border-rose-800/50 backdrop-blur-md shadow-[inset_0_0_15px_rgba(244,63,94,0.05)] font-bold';

              dynamicDataHTML = (
                <div className="text-center">
                  <div className={`text-[11px] mt-1 font-mono font-bold tracking-tight ${textColor}`}>
                    {signSymbol}
                    {sign}
                    {Math.abs(metrics.pnl).toFixed(0)}
                  </div>
                  <div className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">
                    {metrics.count} items
                  </div>
                </div>
              );
            }

            return (
              <div
                key={day}
                className={`p-3 min-h-[90px] rounded-xl shadow-sm flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-md ${classSty}`}
              >
                <div className="text-xs font-black text-slate-500 dark:text-slate-400">{day}</div>
                {dynamicDataHTML}
                <div></div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
