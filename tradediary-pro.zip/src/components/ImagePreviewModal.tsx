import { useState } from 'react';
import { ZoomIn, ZoomOut, Maximize, X } from 'lucide-react';

interface ImagePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageSrc: string;
}

export default function ImagePreviewModal({ isOpen, onClose, imageSrc }: ImagePreviewModalProps) {
  const [zoom, setZoom] = useState<number>(1.0);

  if (!isOpen) return null;

  const handleZoom = (action: 'in' | 'out' | 'reset') => {
    if (action === 'in') {
      setZoom((prev) => Math.min(3, prev + 0.15));
    } else if (action === 'out') {
      setZoom((prev) => Math.max(0.4, prev - 0.15));
    } else {
      setZoom(1.0);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/85 dark:bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-center z-[100] p-4 transition-all">
      <div className="absolute top-6 right-6 flex items-center gap-4 z-[110]">
        <button
          onClick={() => handleZoom('in')}
          className="p-2.5 bg-slate-800 text-white hover:bg-slate-700 transition rounded-xl"
          title="Zoom In"
        >
          <ZoomIn className="w-5 h-5" />
        </button>
        <button
          onClick={() => handleZoom('out')}
          className="p-2.5 bg-slate-800 text-white hover:bg-slate-700 transition rounded-xl"
          title="Zoom Out"
        >
          <ZoomOut className="w-5 h-5" />
        </button>
        <button
          onClick={() => handleZoom('reset')}
          className="p-2.5 bg-slate-800 text-white hover:bg-slate-700 transition rounded-xl"
          title="Reset Zoom"
        >
          <Maximize className="w-5 h-5" />
        </button>
        <button
          onClick={onClose}
          className="p-2.5 bg-rose-600 text-white hover:bg-rose-500 transition rounded-xl"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="w-full h-full max-w-5xl max-h-[80vh] overflow-auto flex items-center justify-center custom-scrollbar p-4">
        <img
          src={imageSrc}
          alt="Chart Layout View"
          className="max-w-full max-h-full object-contain rounded-xl select-none shadow-2xl border border-white/10 transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        />
      </div>
    </div>
  );
}
