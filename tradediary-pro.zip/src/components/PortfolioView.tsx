import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { Trade, AppConfig } from '../types';

interface PortfolioViewProps {
  trades: Trade[];
  appConfig: AppConfig;
  colors: {
    primary: string;
    success: string;
    danger: string;
  };
}

export default function PortfolioView({ trades, appConfig, colors }: PortfolioViewProps) {
  // 1. Calculations
  const assetPnlMap: { [symbol: string]: number } = {};
  const assetVolumeMap: { [symbol: string]: number } = {};
  const assetCountMap: { [symbol: string]: number } = {};
  let totalVolumeSum = 0;

  trades.forEach((t) => {
    const sym = t.symbol.toUpperCase().trim();
    if (!sym) return;

    assetPnlMap[sym] = (assetPnlMap[sym] || 0) + (t.calculatedPl || 0);
    assetVolumeMap[sym] = (assetVolumeMap[sym] || 0) + (t.quantity || 0);
    assetCountMap[sym] = (assetCountMap[sym] || 0) + 1;
    totalVolumeSum += t.quantity || 0;
  });

  const uniqueSymbols = Object.keys(assetVolumeMap);

  // 2. Select palette colors matching customization settings
  const getAssetPalette = (preset: string, totalCount: number): string[] => {
    let basePalette: string[] = [];
    const p = colors.primary;

    switch (preset) {
      case 'neon':
        basePalette = ['#00f5ff', '#ff007f', '#39ff14', '#ffb703', '#8a2be2', '#ff4500', '#00e5ff'];
        break;
      case 'pastel':
        basePalette = ['#bae1ff', '#ffb3ba', '#baffc9', '#ffffba', '#ffdfba', '#e8c4ec', '#c2f0fc'];
        break;
      case 'warm':
        basePalette = ['#f59e0b', '#ef4444', '#f97316', '#ec4899', '#f43f5e', '#d97706', '#b45309'];
        break;
      case 'monochrome':
        // Generate nice shades based on primaryColor or beautiful greys
        basePalette = [
          p,
          `${p}cc`, // 80% opacity
          `${p}99`, // 60% opacity
          `${p}73`, // 45% opacity
          `${p}4d`, // 30% opacity
          '#64748b',
          '#475569',
        ];
        break;
      case 'default':
      default:
        basePalette = [p, '#a855f7', colors.success, '#f59e0b', '#3b82f6', '#ec4899', colors.danger];
        break;
    }

    // Dynamic fallback generation if more items exist
    while (basePalette.length < totalCount) {
      basePalette.push('#' + Math.floor(Math.random() * 16777215).toString(16));
    }

    return basePalette;
  };

  const paletteColors = getAssetPalette(appConfig.theme.palette || 'default', uniqueSymbols.length);

  // Allocation Chart Data for Recharts Pie
  const allocationChartData = uniqueSymbols.map((sym, index) => ({
    name: sym,
    value: assetVolumeMap[sym] || 0.1,
    color: paletteColors[index],
  }));

  return (
    <div className="tab-content animate-fade-in space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Aggregated Live Assets Table */}
        <div className="lg:col-span-2 glass-panel rounded-2xl overflow-hidden flex flex-col transition-all duration-300">
          <div className="px-6 py-4 border-b border-white/20 dark:border-slate-800/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
              Aggregated Live Assets
            </h3>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100/50 dark:bg-slate-900/50 border-b border-slate-200/50 dark:border-slate-800/50 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                  <th className="px-6 py-4">Asset Symbol</th>
                  <th className="px-6 py-4">Total Volume</th>
                  <th className="px-6 py-4">Trades Run</th>
                  <th className="px-6 py-4">Net Returns</th>
                  <th className="px-6 py-4">Allocation Weight</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/50 dark:divide-slate-800/50 text-sm">
                {uniqueSymbols.length === 0 ? (
                  <tr>
                    <td
                      colSpan={5}
                      className="px-6 py-12 text-center text-xs font-bold tracking-widest uppercase text-slate-500"
                    >
                      No open asset models tracked.
                    </td>
                  </tr>
                ) : (
                  uniqueSymbols.map((sym) => {
                    const volume = assetVolumeMap[sym] || 0;
                    const count = assetCountMap[sym] || 0;
                    const netPl = assetPnlMap[sym] || 0;
                    const weight = totalVolumeSum > 0 ? ((volume / totalVolumeSum) * 100).toFixed(1) : '0.0';

                    return (
                      <tr
                        key={sym}
                        className="border-b border-slate-200/50 dark:border-slate-800/50 hover:bg-white/50 dark:hover:bg-slate-900/40 transition-colors text-xs font-semibold text-slate-700 dark:text-slate-300"
                      >
                        <td className="px-6 py-4 font-bold text-slate-900 dark:text-white tracking-wide">
                          {sym}
                        </td>
                        <td className="px-6 py-4 font-mono">{volume.toLocaleString()} units</td>
                        <td className="px-6 py-4">{count} execution steps</td>
                        <td className={`px-6 py-4 font-mono ${netPl >= 0 ? 'text-emerald-500' : 'text-rose-500'} font-bold`}>
                          ₹{netPl.toFixed(2)}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <span className="w-10 text-right font-mono">{weight}%</span>
                            <div className="w-24 bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                              <div className="bg-primary h-full" style={{ width: `${weight}%` }}></div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Asset Allocation Pie Chart */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col justify-between transition-all duration-300">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
              Asset Allocation
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 mt-1 font-medium tracking-tight">
              Capital concentration map
            </p>
          </div>
          <div className="h-64 relative flex items-center justify-center">
            {uniqueSymbols.length === 0 ? (
              <div className="text-slate-400 text-xs font-bold uppercase tracking-widest text-center mt-12">
                No allocation data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={allocationChartData}
                    innerRadius="40%"
                    outerRadius="75%"
                    dataKey="value"
                    stroke="none"
                  >
                    {allocationChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#f8fafc',
                    }}
                  />
                  <Legend
                    iconSize={8}
                    layout="horizontal"
                    verticalAlign="bottom"
                    align="center"
                    wrapperStyle={{ fontSize: '11px', marginTop: '10px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
