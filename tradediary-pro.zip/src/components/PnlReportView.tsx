import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { Trade } from '../types';

interface PnlReportViewProps {
  trades: Trade[];
  colors: {
    success: string;
    danger: string;
    tick: string;
  };
}

export default function PnlReportView({ trades, colors }: PnlReportViewProps) {
  // Calculations
  const winTrades = trades.filter((t) => (t.calculatedPl || 0) >= 0);
  const lossTrades = trades.filter((t) => (t.calculatedPl || 0) < 0);

  const winsCount = winTrades.length;
  const lossesCount = lossTrades.length;
  const totalCount = trades.length;

  const grossProfit = winTrades.reduce((acc, t) => acc + (t.calculatedPl || 0), 0);
  const grossLoss = lossTrades.reduce((acc, t) => acc + Math.abs(t.calculatedPl || 0), 0);
  const netProfit = grossProfit - grossLoss;

  const avgWin = winsCount > 0 ? grossProfit / winsCount : 0;
  const avgLoss = lossesCount > 0 ? grossLoss / lossesCount : 0;

  // Streaks calculation
  const chronTrades = [...trades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  let maxWinStreak = 0;
  let maxLossStreak = 0;
  let currentWinStreak = 0;
  let currentLossStreak = 0;

  chronTrades.forEach((t) => {
    const pl = t.calculatedPl || 0;
    if (pl >= 0) {
      currentWinStreak++;
      maxLossStreak = Math.max(maxLossStreak, currentLossStreak);
      currentLossStreak = 0;
    } else {
      currentLossStreak++;
      maxWinStreak = Math.max(maxWinStreak, currentWinStreak);
      currentWinStreak = 0;
    }
  });
  maxWinStreak = Math.max(maxWinStreak, currentWinStreak);
  maxLossStreak = Math.max(maxLossStreak, currentLossStreak);

  // Expectancy
  const winRate = totalCount > 0 ? winsCount / totalCount : 0;
  const lossRate = totalCount > 0 ? lossesCount / totalCount : 0;
  const expectancy = winRate * avgWin - lossRate * avgLoss;

  // Win/Loss Ratio
  const wlRatio = avgLoss > 0 ? (avgWin / avgLoss).toFixed(2) : '0.00';

  // Group P&L by Ticker/Asset for chart
  const assetPnlMap: { [symbol: string]: number } = {};
  trades.forEach((t) => {
    const sym = t.symbol.toUpperCase().trim();
    if (sym) {
      assetPnlMap[sym] = (assetPnlMap[sym] || 0) + (t.calculatedPl || 0);
    }
  });
  const assetPnlData = Object.keys(assetPnlMap).map((sym) => ({
    name: sym,
    value: assetPnlMap[sym],
  }));

  // Monthly Time Distribution Table grouping
  const monthMap: { [key: string]: { pnl: number; count: number } } = {};
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  trades.forEach((t) => {
    if (!t.date) return;
    const d = new Date(t.date);
    const key = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
    if (!monthMap[key]) {
      monthMap[key] = { pnl: 0, count: 0 };
    }
    monthMap[key].pnl += t.calculatedPl || 0;
    monthMap[key].count++;
  });

  const monthlyList = Object.keys(monthMap).map((m) => ({
    month: m,
    pnl: monthMap[m].pnl,
    count: monthMap[m].count,
  }));

  return (
    <div className="tab-content animate-fade-in space-y-8">
      {/* 2-Column Ledger Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Win statistics */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4 border-b border-slate-200/50 dark:border-slate-800 pb-3 flex justify-between items-center">
            <span>Statistics on Wins</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
          </h3>
          <div className="space-y-4 font-mono text-sm font-semibold text-slate-700 dark:text-slate-300">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-400 tracking-wider uppercase font-sans">
                Gross Profit:
              </span>
              <span className="text-emerald-500 font-bold">₹{grossProfit.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-400 tracking-wider uppercase font-sans">
                Avg Winning Trade:
              </span>
              <span className="text-emerald-500 font-bold">₹{avgWin.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-400 tracking-wider uppercase font-sans">
                Max Win Streak:
              </span>
              <span className="text-emerald-500 font-black">{maxWinStreak} consecutive wins</span>
            </div>
          </div>
        </div>

        {/* Loss statistics */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4 border-b border-slate-200/50 dark:border-slate-800 pb-3 flex justify-between items-center">
            <span>Statistics on Losses</span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
          </h3>
          <div className="space-y-4 font-mono text-sm font-semibold text-slate-700 dark:text-slate-300">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-400 tracking-wider uppercase font-sans">
                Gross Loss:
              </span>
              <span className="text-rose-500 font-bold">₹{grossLoss.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-400 tracking-wider uppercase font-sans">
                Avg Losing Trade:
              </span>
              <span className="text-rose-500 font-bold">₹{avgLoss.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-400 tracking-wider uppercase font-sans">
                Max Loss Streak:
              </span>
              <span className="text-rose-500 font-black">{maxLossStreak} consecutive losses</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dynamic Efficiency Row */}
      <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-6 border-b border-slate-200/50 dark:border-slate-800 pb-3">
          Efficiency Metrics & Returns
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center font-mono">
          <div className="p-4 bg-slate-100/50 dark:bg-slate-900/50 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
            <div className="text-slate-400 text-[10px] font-bold uppercase tracking-widest font-sans mb-1">
              Total Count
            </div>
            <div className="text-2xl font-black text-slate-800 dark:text-white">{totalCount}</div>
          </div>
          <div className="p-4 bg-slate-100/50 dark:bg-slate-900/50 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
            <div className="text-slate-400 text-[10px] font-bold uppercase tracking-widest font-sans mb-1">
              Win/Loss Ratio
            </div>
            <div className="text-2xl font-black text-primary">{wlRatio}</div>
          </div>
          <div className="p-4 bg-slate-100/50 dark:bg-slate-900/50 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
            <div className="text-slate-400 text-[10px] font-bold uppercase tracking-widest font-sans mb-1">
              Expectancy (₹)
            </div>
            <div
              className={`text-2xl font-black ${
                expectancy >= 0 ? 'text-emerald-500' : 'text-rose-500'
              }`}
            >
              ₹{expectancy.toFixed(2)}
            </div>
          </div>
          <div className="p-4 bg-slate-100/50 dark:bg-slate-900/50 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
            <div className="text-slate-400 text-[10px] font-bold uppercase tracking-widest font-sans mb-1">
              Total Net P&L (₹)
            </div>
            <div
              className={`text-2xl font-black ${
                netProfit >= 0 ? 'text-emerald-500' : 'text-rose-500'
              }`}
            >
              ₹{netProfit.toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: P&L Chart by Asset & Monthly distribution List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart */}
        <div className="glass-panel rounded-2xl p-6 transition-all duration-300">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">
            P&L by Asset (Gross breakdown)
          </h3>
          <div className="h-64">
            {assetPnlData.length === 0 ? (
              <div className="text-xs text-slate-500 font-bold uppercase tracking-widest text-center mt-12">
                No asset P&L logged yet
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={assetPnlData}>
                  <XAxis dataKey="name" stroke={colors.tick} tickLine={false} fontSize={11} />
                  <YAxis stroke={colors.tick} tickLine={false} fontSize={11} />
                  <Tooltip
                    cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#f8fafc',
                    }}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {assetPnlData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.value >= 0 ? colors.success : colors.danger}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Monthly distribution logs */}
        <div className="glass-panel rounded-2xl overflow-hidden shadow-sm flex flex-col transition-all duration-300">
          <div className="px-6 py-4 border-b border-white/20 dark:border-slate-800/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-widest uppercase">
              Monthly Time Distribution
            </h3>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100/50 dark:bg-slate-900/50 border-b border-slate-200/50 dark:border-slate-800/50 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                  <th className="px-6 py-4">Time Period</th>
                  <th className="px-6 py-4">Action Volume</th>
                  <th className="px-6 py-4">Net Periodic Return</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/50 dark:divide-slate-800/50 text-sm font-medium">
                {monthlyList.length === 0 ? (
                  <tr>
                    <td
                      colSpan={3}
                      className="px-6 py-12 text-center text-xs font-bold tracking-widest uppercase text-slate-500"
                    >
                      No monthly ledger models tracked.
                    </td>
                  </tr>
                ) : (
                  monthlyList.map((m) => (
                    <tr
                      key={m.month}
                      className="hover:bg-white/50 dark:hover:bg-slate-900/40 transition-colors text-xs font-semibold text-slate-700 dark:text-slate-300"
                    >
                      <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">{m.month}</td>
                      <td className="px-6 py-4 font-mono">{m.count} logs entered</td>
                      <td className={`px-6 py-4 font-mono ${m.pnl >= 0 ? 'text-emerald-500' : 'text-rose-500'} font-bold`}>
                        {m.pnl >= 0 ? '+' : ''}₹{m.pnl.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
