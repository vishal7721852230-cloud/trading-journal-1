export interface ThemeConfig {
  primaryColor: string;
  successColor: string;
  dangerColor: string;
  bgLight: string;
  bgDark: string;
  bg: 'mesh' | 'solid' | 'gradient';
  font: string;
  palette: 'default' | 'neon' | 'pastel' | 'warm' | 'monochrome';
  chartGridColor: string;
}

export interface AppConfig {
  brandName: string;
  strategies: string[];
  ecosystems: string[];
  outcomes: string[];
  mistakes: string[];
  theme: ThemeConfig;
}

export interface Trade {
  date: string;
  symbol: string;
  marketCondition: string;
  currency: 'INR' | 'USD';
  entryPrice: number;
  quantity: number;
  exitPrice: number;
  stopLossPrice: number;
  targetPrice: number;
  manualPnlAmount: number | '';
  calculatedPl?: number;
  direction: 'LONG' | 'SHORT';
  tradeDuration: 'INTRADAY' | 'SWING';
  strategyTag: string;
  tradeStatus: 'WIN' | 'LOSS';
  ratingConfidence: number;
  ratingSatisfaction: number;
  emotionalState: string;
  lessonsLearned: string;
  mistakesMade: string[];
  chartImage: string;
}
